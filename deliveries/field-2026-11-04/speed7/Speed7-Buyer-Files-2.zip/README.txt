SPEED7 | FIVE-PAGE BILINGUAL TASK LISTS
速寫7｜五頁極簡待辦清單

FILES / 文件
Speed7-A4.pdf — 5 pages, A4 210 × 297 mm.
Speed7-US-Letter.pdf — 5 pages, US Letter 8.5 × 11 inches.
Both files contain the same five pages. English and Traditional Chinese share each writing area; these are not separate language editions.
兩份檔案內容相同；每頁英文與繁體中文共用填寫欄，不是分語言版本。

USE / 使用方式
Choose the PDF that matches your paper. Open it in a PDF reader, choose 100% / Actual Size and the matching paper size, and print the pages you want to use. Write by hand. Use a fresh print when needed.
選擇與紙張相符的PDF；以PDF閱讀器開啟，選擇100%／實際大小及相符紙型，再打印需要的頁面。用筆手寫；需要時重新打印。

These are ordinary printable PDFs, with no interactive form fields, automatic calculations or synchronization. No physical product is included.
這是普通打印PDF，沒有互動表單欄位、自動計算或同步功能；不包含實體商品。

CONTENTS / 內容
1. Brain Dump / 全部倒出來
2. Sort It Honestly / 分一分
3. Today’s Honest Three / 今天只做三件
4. Weekly Inventory / 一週盤點
5. Next Week, Blank / 下週空白表

Personal task organization and task review only. Not a psychological assessment or treatment tool.
僅供整理與盤點待辦事項，不是心理評估或治療工具。

Digital opening, rendering, dimensions, content and row/checkbox counts were checked. Physical printing and particular printers have not been tested. Printer margins and settings may vary.
已檢查數位檔開啟、渲染、尺寸、內容及橫線／勾選框數量。未進行實體打印或特定打印機測試；打印機邊距與設定可能不同。

Read PERSONAL_USE_LICENSE.txt. / 請閱讀個人使用許可。
