# 第一波热点场执行单 — 标题/标签/描述批量改造（2026-10-24 备齐）

> 材料：TITLE-TAG-PACK.md（标题/标签）、DESC-PACK.md（描述三块）、SHEETS-PIN-PACK.md（Pin 规格，本场不发 pin）。
> 纪律：Lee 登录＋亲手 Publish；Muse 经 Lee 的 Mac 填表；Suggested title 弹窗一律 Dismiss；任一项校验对不上即 STOP、Discard 回滚、跳过该款、下线处理。
> 本场不做：冻结组 3 款标题（Restart/2027×2 只看不动）、表格文件改造（Start Here tab 等属构建场）、pin 发布（等 Share & Save 链接）。

## 开场动作（先做，一次）
1. Lee 在 Shop Manager → Marketing → Share & Save 点 Join now（约 30 秒）；Muse 记录店铺 Share & Save 链接格式，备 pin 回填用。
2. 打开 Listings 页，逐款按下面顺序执行。

## 逐款步骤（每款同一套路）
开编辑页 → Dismiss 标题建议 → 标题：逐字粘新标题、核编辑器字符数＝包内标注 → 标签：仅圣诞款/P1 按包换（P1 先核 moving checklist 是否已在）→ 描述：按 DESC-PACK 粘贴总则贴 (a) 首屏块于最前、(c) QUESTIONS（7 款有）、(b) 互链块于落款前；有中段旧指引句的款删旧句 → 校验：每块字符数与包内标注一致（fill 回执口径）→ Lee 点 Publish → 回 Listings 为成功旁证。
※ 习惯入门版：粘标题前先扫现行标题，核对尾段错词（Morning Evening Routine）是否属实再粘。
※ D4：看标签里 adhd planner printable 是否已换（10-22 定案），是旧词 adhd printable 就顺手补换。

## 各款描述预期总长（UTF-16，发布前校验基准；含中段删句的款以分块计数为准）
- Savings Full 2342｜Habit Full 1988｜Budget Full 2233｜2027 Full 3112
- Savings Starter 1825*｜Habit Starter 1816*｜Budget Starter 1664*｜2027 Starter 1778*（*含删中段旧指引句，总长以三块计数＋删句长度另计）
- D3 5220｜D4 4665｜Restart 4855｜P1 7193
- Christmas Kit / D5 / S-006：基线在各自上架包，以 DESC-PACK 分块计数逐块核对。

## 顺手核查（同场）
- Budget Starter：打开编辑页看「Photos 影响曝光」提醒具体所指，当场定因（补图/重排），处理不了就截图存档跳过。

## 场后（下线）
- 逐款回读公开页标题＋描述首尾存档；更新 POST-LAUNCH-30D-TRACKER 备注（改版日期）；Share & Save 链接回填 SHEETS-PIN-PACK 的 5 条 pin，进入 pin 制作。

## 审核后补入（2026-10-24，源：PURCHASE-REASONS.md 购买理由挖掘，已审）
- D3 首屏块末尾加一句（买家评价证实类目第一劝退点是「太复杂」，D3 的一页核心结构是真防线但页面没说清）：`Start with one page — the Bill Split page. Everything else is there when you need it.`（该句 UTF-16 实算 85；加换行后 D3 描述新预期总长 5220＋86＝5306，进场以 fill 回执为准。）
