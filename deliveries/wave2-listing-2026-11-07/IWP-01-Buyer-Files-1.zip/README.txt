IWP-01 — Interactive Weekly Planner (Undated)
==============================================

WHAT THIS IS
An undated weekly planner in two sizes. Navigation is built in: tap a tab
or a contents line and you jump straight to that page. It also prints like
an ordinary planner — the links are a screen-only feature and never print.

FILES
- IWP-01-Interactive-Weekly-Planner_A4.pdf ..... A4 (210 x 297 mm)
- IWP-01-Interactive-Weekly-Planner_Letter.pdf . US Letter (8.5 x 11 in)
Both files have the same 10 pages and the same fields. Use the size that
matches your paper.

THE PAGES
1  Cover — with a clickable contents list.
2  How to use this planner — includes the navigation map.
3  Month overview — twelve undated month boxes.
4  Week at a glance — one week, day by day (the core page).
5  Priorities — weekly focus and your top 3.
6  Week review — what worked, what did not, what carries forward.
7  Habit tracker — one month, 31 days, 8 habits.
8  Brain dump — free notes space.
9  Task inbox — catch tasks, then sort them: today / this week.
10 Notes — spare lined page.

HOW THE LINKS WORK
- On the cover, tap any line in the Contents to jump to that section.
- On page 2, tap any line in the navigation map.
- Pages 3–10 carry the same tab bar at the top: Cover / Month / Week /
  Priorities / Review / Habits / Dump / Tasks / Notes. Tap a tab to jump.
  The tab of the page you are on is shown in black.
- Tap a page's title to jump back to the cover. Page 10 also has a
  "Back to cover" link at the bottom.
Links need a PDF reader on a screen (computer, tablet or phone). They do
not print and do not change the printed page in any way.

THE FIELDS
Every box, line and checkbox is a form field. Open the PDF in a reader
that supports forms (for example Adobe Acrobat Reader, which is free),
type or tap, then save the file — your entries stay in the file when you
reopen it. Checkboxes tick with a tap or click.
Fields by page: cover (your name), month boxes (month + notes), week page
(week-of, a date and notes for each day), priorities (focus, top 3, extra
lines), review (three boxes), habit tracker (month, habit names, 248 day
checkboxes), brain dump and notes (free text), task inbox (a checkbox and
a line for each task).

PRINTING
Print at 100% / Actual size (do not use "Fit to page" — it shrinks the
page). Print the whole file, or a single page whenever you need a fresh
one; every page works on its own. Filled-in fields print with your text;
blank fields print as blank lines and boxes.

UNDATED
No year is printed anywhere. Fill in the months and dates yourself, start
in any week of any year, and reuse the file for as long as you like.

LICENSE
Personal use only — see PERSONAL_USE_LICENSE.txt.
