ANNUAL BUDGET EXTENSION / 年度預算延伸包

OPEN AND USE
Open Annual-Budget-Extension.xlsx in a spreadsheet application. Save a copy before entering your own data. Only light-blue cells are inputs. Use one currency throughout. Enter amounts as numbers, without currency symbols or words. Grey/white totals calculate automatically.
打開Excel工作簿，先另存副本。只在淺藍格輸入；全包使用同一幣別；金額只輸入數字，不加符號或文字。灰／白合計格會自動計算。

FOUR SHEETS
Extension at a Glance shows the planned/actual totals of the three detail sheets and the extension total. It has no amount inputs.
Non-Monthly Bills records one bill/payment per row, including the due date you enter.
Home Maintenance Budget records one project expense per row and its category.
Family Events Budget records one expense per row and the event name as its category.
總覽顯示三表計畫／實際合計及二期總額，不需輸入金額。非每月帳單逐筆填寫到期日；居家維護按項目及分類記錄；家庭活動按支出項目及活動名稱記錄。

CAPACITY AND GROUP TOTALS
Each detail sheet has 24 rows, rows 8–31. Home/Family have six editable group labels in A37:A42. Enter each label once, exactly matching the labels in detail column B. Avoid wildcard characters *, ? and ~ in labels. Whole-sheet and overview totals include all numeric detail amounts, even labels absent from the group summary. Repeating a summary label repeats its displayed subtotal but does not inflate overall totals. No automatic row expansion is included.
每表24行；居家／家庭各有6個分類合計名稱，請只列一次並與B欄明細完全相同，避免萬用字元。全表及總覽包含所有數字明細，沒有列入分類摘要的金額也計入。重複分類名稱會重複顯示該小計，但不會重複增加總額。沒有自動擴充行數。

INPUT LIMITS
Negative numeric adjustments/refunds reduce totals. Text in amount cells is highlighted red and SUM ignores it: correct all red inputs before relying on totals. Pasted formulas can create errors; paste values only. Formula errors propagate and are not hidden as zero. Formula cells are not protected; do not overwrite them.
負數可記退款／沖銷並減少合計。文字金額顯示紅色且不計入SUM，使用總額前須修正。只貼上值；貼上公式可能產生錯誤。錯誤不會被掩蓋成零。公式格沒有鎖定，請勿覆寫。

ONE PAYMENT, ONE ENTRY
Duplicate expenses and payments entered on multiple sheets count multiple times. No automatic deduplication exists. Enter each payment once on one detail sheet. If the same expense is also recorded in Phase 1, do not add both workbook totals together. Phase 2 never reads/writes Phase 1, and there is no bank import, forecast, debt model or two-way sync.
重複列／跨表重複付款都會再計入，沒有自動去重。每筆付款只記一次；如一期也記有同筆費用，不可把兩本總額相加。二期不讀寫一期，不連銀行，不作預測／債務模擬或雙向同步。

PAPER COPIES
Choose A4 or US Letter PDF to match your paper. Print at 100% / actual size. Both have six static pages with blank spaces for handwriting and manual totals. They have no interactive fields or formulas, and do not update the workbook.
選擇符合紙張的A4／Letter PDF，以100%實際尺寸打印。各6頁，空白欄供手寫，合計須自行計算；沒有可填寫欄位／公式，也不與工作簿同步。

TEST LIMITS
Digital structure, formula tests and actual LibreOffice reopen/recalculation have been checked. Actual Microsoft Excel, Google Sheets account/UI and physical printing were not tested. No hosted Google Sheets link is included. Do not interpret the file format as a completed test in every application.
已檢查數字結構、公式及LibreOffice實際重開重算；未在真實Excel／Google Sheets介面或實體打印環境測試，不含Google Sheets複製連結。

Personal use only. See PERSONAL_USE_LICENSE.txt. No physical product is supplied.
