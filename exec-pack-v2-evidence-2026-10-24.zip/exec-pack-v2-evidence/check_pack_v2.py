#!/usr/bin/env python3
# Independent checker for EXECUTION-PACK-V2.md.
# Recomputes everything from live-captures + the approved sentences typed
# here from the session pack (not imported from the generator), then verifies
# the pack file's printed expectations and each Stage B script's embedded
# B/A arrays and APP string.
import struct, pathlib, re, sys

BASE = pathlib.Path(__file__).parent
CAP = BASE / 'live-captures'

def stats(s):
    b = s.encode('utf-16-le')
    u = struct.unpack('<' + 'H' * (len(b) // 2), b)
    h = 5381
    for c in u:
        h = ((h * 33) + c) & 0xFFFFFFFF
    return len(u), h

S1 = "This digital product was created with AI assistance in design and production, with seller-directed development and review."
S2D = "Some listing images use AI-assisted mockups. The product previews represent the actual digital files, and a completed example is included in the download."
S2N = "Some listing images use AI-assisted mockups. The product previews represent the actual digital files you will receive."

# name, listing id, capture file, branch, evening-recorded before (LEN, HASH)
ROWS = [
    ('P1', '4600844093', 'LIVE-DESC-P1-4600844093-2026-10-23.txt', 'delivered', (4438, 390779962)),
    ('D3', '4600362280', 'LIVE-DESC-D3-4600362280-2026-10-23.txt', 'noexample', (2700, 2517623996)),
    ('D4', '4600823259', 'LIVE-DESC-D4-4600823259-2026-10-23.txt', 'noexample', (2456, 3967344857)),
    ('Savings Full', '4598465559', 'LIVE-DESC-SAVINGSFULL-4598465559-2026-10-23.txt', 'none', (1154, 1895881291)),
    ('Savings Starter', '4598538460', 'LIVE-DESC-SAVINGSSTARTER-4598538460-2026-10-23.txt', 'none', (955, 3375102119)),
    ('Habit Full', '4598582424', 'LIVE-DESC-HABITFULL-4598582424-2026-10-23.txt', 'none', (898, 1900152835)),
    ('Habit Starter', '4598576567', 'LIVE-DESC-HABITSTARTER-4598576567-2026-10-23.txt', 'none', (918, 3316711530)),
    ('Budget Full', '4598655675', 'LIVE-DESC-BUDGETFULL-4598655675-2026-10-23.txt', 'none', (964, 2019279411)),
    ('Budget Starter', '4598659063', 'LIVE-DESC-BUDGETSTARTER-4598659063-2026-10-23.txt', 'none', (781, 1488512307)),
    ('2027 Full', '4598684850', 'LIVE-DESC-2027FULL-4598684850-2026-10-23.txt', 'none', (1964, 1563019068)),
    ('2027 Starter', '4598687922', 'LIVE-DESC-2027STARTER-4598687922-2026-10-23.txt', 'none', (876, 814624612)),
    ('Restart', '4600838577', 'LIVE-DESC-RESTART-4600838577-2026-10-23.txt', 'delivered', (2629, 380867584)),
]

def app_of(branch):
    if branch == 'delivered':
        return "\n\n" + S1 + "\n\n" + S2D
    if branch == 'noexample':
        return "\n\n" + S1 + "\n\n" + S2N
    return "\n\n" + S1

pack = (BASE / 'EXECUTION-PACK-V2.md').read_text(encoding='utf-8')
fails = []

for name, lid, fn, branch, recorded in ROWS:
    text = (CAP / fn).read_text(encoding='utf-8')
    if stats(text) != recorded:
        fails.append(name + ': capture stats != evening record ' + str(stats(text)))
    if 'AI assistance' in text:
        fails.append(name + ': capture already contains S1')
    fixed = text
    if name == 'P1':
        if text.count('loses nothingYOU WILL RECEIVE') != 1:
            fails.append('P1: glue pattern count != 1')
        fixed = text.replace('loses nothingYOU WILL RECEIVE', 'loses nothing\n\nYOU WILL RECEIVE')
    app = app_of(branch)
    b1, b2 = stats(text), stats(text + '\n')
    a1, a2 = stats(fixed + app), stats(fixed + '\n' + app)
    # printed expectations in pack
    line_b = '期望 before：LEN=%d HASH=%d（带尾换行变体：LEN=%d HASH=%d' % (b1[0], b1[1], b2[0], b2[1])
    line_a = '期望 after：LEN=%d HASH=%d' % (a1[0], a1[1])
    if line_b not in pack:
        fails.append(name + ': before line missing/mismatch in pack')
    if line_a not in pack:
        fails.append(name + ': after line missing/mismatch in pack')
    # embedded script for this listing
    m = re.search(r'const ID="' + lid + r'";const B=\[\[(\d+),(\d+)\],\[(\d+),(\d+)\]\];const A=\[\[(\d+),(\d+)\],\[(\d+),(\d+)\]\];const APP="((?:[^"\\]|\\.)*)"', pack)
    if not m:
        fails.append(name + ': stage B script not found')
        continue
    nums = [int(x) for x in m.groups()[:8]]
    if nums != [b1[0], b1[1], b2[0], b2[1], a1[0], a1[1], a2[0], a2[1]]:
        fails.append(name + ': script B/A arrays mismatch ' + str(nums))
    embedded_app = m.group(9).encode().decode('unicode_escape')
    if embedded_app != app:
        fails.append(name + ': script APP string mismatch')
    if name == 'P1' and 'loses nothing\\n\\nYOU WILL RECEIVE' not in pack:
        fails.append('P1: fixed-pattern string missing in pack script')

if fails:
    print('FAIL')
    for f in fails:
        print(' -', f)
    sys.exit(1)
print('ALL CHECKS PASS: 12 listings, captures match evening records, pack expectations and embedded scripts verified byte-level')
