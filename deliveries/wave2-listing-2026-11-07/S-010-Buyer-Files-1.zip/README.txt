Study Planner (S-010)
=====================

WHAT'S INSIDE (18 pages)
- Semester Overview (pages 3-4): every due date for the whole
  term, in one place.
- 12 Weekly Plan pages (pages 5-16), one per week: the week's
  deadlines in a table at the top, a full notes section below.
- Subject Notes (page 17): notes by subject.
- Final Check (page 18): end-of-term checklist + exam countdown.

Files: S-010-Study-Planner_A4.pdf and S-010-Study-Planner_Letter.pdf
- same 18 pages, two paper sizes. Print whichever matches your paper.

HOW TO USE
1. In your first week, fill in the Semester Overview with every
   due date you already know. Add new dates as they are announced.
2. Each week, take one Weekly Plan page. Write the week's
   deadlines in the top table - day, subject, assignment, due
   date - and tick them off as you finish.
3. Use the notes section under the table for everything else:
   reminders, questions to ask, ideas, rough plans.
4. Keep class notes and assignment details on the Subject Notes
   page. Print that page again whenever you need more blocks.
5. Near the end of term, work through the Final Check page.

PRINTING
- Print in black and white at 100%, or choose "Fit to page".
- The Contents links (page 2) work on screen in a PDF reader;
  on paper they do nothing.
- Print single pages whenever you like - each week stands alone.

LICENSE
Personal use only - see PERSONAL_USE_LICENSE.txt.

Questions about your order? Message us through the shop.
