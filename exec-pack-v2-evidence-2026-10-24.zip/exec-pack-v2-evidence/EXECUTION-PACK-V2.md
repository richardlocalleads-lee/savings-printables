# DISCLOSURE-FIX EXECUTION PACK V2 - rebuilt offline 2026-10-24 from live captures

现场唯一文件。基线 = 2026-10-23 晚场从 Etsy 编辑页逐款抓取的线上全文（live-captures/，每份已在 VM 侧逐字复算 LEN/djb2，与页面阶段 A 读数 12/12 全等）。v1 执行包（旧源稿基线）作废，以本包为准。
本包覆盖 12 款：原 11 款 + Restart（Lee 2026-10-23 23:47 批准以线上弯引号版为基线，一并追加）。P1 额外补回「YOU WILL RECEIVE」前丢失的段落空行（同场批准）。
现场只执行不议事：逐款 开页 → 阶段 A 校验 → 阶段 B 脚本（内含硬门）→ Lee 点发布 → 发布后复核。
校验口径：LEN = UTF-16 码元数；HASH = djb2（h=5381；h=((h*33)+c)>>>0；逐 UTF-16 码元）。djb2 只作快速变异哨兵；证明标准 = 改前/改后全文 + 发布后回读差异比对。

## 现场五步（每款）

1. 新标签开该款编辑页（带 #item-details），等加载完。
2. 地址栏跑阶段 A 脚本（文末通用）：CHECK 行 LEN/HASH 命中该款期望 before（主值或带尾换行变体）、AI=NO 才继续；不符 → 跑抓取脚本存档 → 跳过该款，现场不分析。
3. 跑该款阶段 B 脚本：脚本内硬门（URL 含 listing ID、before 命中允许变体、原文不含 S1）任一不过即亮红 STOP 不写入；全过才写入并自检 after，亮绿 AFTER OK + 标题栏 AFTER_OK、编辑器显示「1 unsaved change: Description」→ 请 Lee 点 Publish changes。
4. Lee 发布后刷新编辑页，再跑阶段 A：LEN/HASH = 期望 after、AI=YES → 完成，回填清单与日志。
5. Suggested title 弹窗一律 Dismiss、永不 Apply；标题/价格/标签/图片/交付文件一律不动。

## 句子组件（已批准定版，逐字）

S1 产品句（122 字符）：This digital product was created with AI assistance in design and production, with seller-directed development and review.
S2 示例随货版（154 字符）：Some listing images use AI-assisted mockups. The product previews represent the actual digital files, and a completed example is included in the download.
S2 无示例版（118 字符）：Some listing images use AI-assisted mockups. The product previews represent the actual digital files you will receive.
追加方式：原文末尾 + \n\n + S1（+ \n\n + S2，视分支）。P1 先做段落修复再追加。

## 各款执行单

### 1. P1 Parents' Move Command Center (4600844093) - 图片句分支：DELIVERED

- 编辑页：https://www.etsy.com/your/shops/me/listing-editor/edit/4600844093#item-details
- 基线文件：live-captures/LIVE-DESC-P1-4600844093-2026-10-23.txt
- 分支依据（英文备查）：image set includes a filled example; the EXAMPLE file is in the delivered set (verified 2026-10-23)
- **段落修复（已批准）**：线上正文 “…loses nothing” 与 “YOU WILL RECEIVE” 粘连（缺段落空行）；阶段 B 脚本在追加披露之前，先把该处替换为 “loses nothing\n\nYOU WILL RECEIVE”，再追加。除此一处外正文一字不动。
- 期望 before：LEN=4438 HASH=390779962（带尾换行变体：LEN=4439 HASH=10836868，其 after 为 LEN=4721 HASH=2922829261）
- 期望 after：LEN=4720 HASH=3792743939
- 阶段 B 脚本：`javascript:(()=>{const ID="4600844093";const B=[[4438,390779962],[4439,10836868]];const A=[[4720,3792743939],[4721,2922829261]];const APP="\n\nThis digital product was created with AI assistance in design and production, with seller-directed development and review.\n\nSome listing images use AI-assisted mockups. The product previews represent the actual digital files, and a completed example is included in the download.";const H=s=>{let h=5381;for(let i=0;i<s.length;i++){h=((h*33)+s.charCodeAt(i))>>>0;}return h;};const ban=(m,c)=>{const d=document.createElement('div');d.style.cssText='position:fixed;top:0;left:0;z-index:99999;background:'+c+';color:#000;font-size:20px;padding:8px';d.textContent=m;document.body.appendChild(d);};const stop=m=>{ban('STOP '+m,'#f99');document.title='STOP';};if(!location.href.includes(ID)){stop('WRONG PAGE');return;}const t=[...document.querySelectorAll('textarea')].find(e=>e.value.length>400);if(!t){stop('NOFIND');return;}const old=t.value;const bi=B.findIndex(p=>old.length===p[0]&&H(old)===p[1]);if(bi<0){stop('BEFORE MISMATCH LEN='+old.length+' HASH='+H(old));return;}if(old.includes('AI assistance')){stop('S1 ALREADY PRESENT');return;}const nv0=old.replace("loses nothingYOU WILL RECEIVE","loses nothing\n\nYOU WILL RECEIVE");if(nv0===old||!nv0.includes("loses nothing\n\nYOU WILL RECEIVE")){stop('P1 FIX FAILED');return;}const nv=nv0+APP;const exp=A[bi];if(nv.length!==exp[0]||H(nv)!==exp[1]){stop('AFTER MISMATCH LEN='+nv.length+' HASH='+H(nv));return;}const st=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,'value').set;st.call(t,nv);t.dispatchEvent(new Event('input',{bubbles:true}));t.dispatchEvent(new Event('change',{bubbles:true}));ban('AFTER OK LEN='+nv.length+' HASH='+H(nv),'#cfc');document.title='AFTER_OK';})()`
- [ ] A 校验  [ ] B 追加核验  [ ] Lee 发布  [ ] 发布后复核

### 2. D3 Biweekly Paycheck Budget Planner (4600362280) - 图片句分支：NOEXAMPLE

- 编辑页：https://www.etsy.com/your/shops/me/listing-editor/edit/4600362280#item-details
- 基线文件：live-captures/LIVE-DESC-D3-4600362280-2026-10-23.txt
- 分支依据（英文备查）：M1-M3 are AI desk mockups showing delivered files in blank state; no filled example (visually checked 2026-10-23)
- 期望 before：LEN=2700 HASH=2517623996（带尾换行变体：LEN=2701 HASH=1477213254，其 after 为 LEN=2945 HASH=1742017654）
- 期望 after：LEN=2944 HASH=1443519468
- 阶段 B 脚本：`javascript:(()=>{const ID="4600362280";const B=[[2700,2517623996],[2701,1477213254]];const A=[[2944,1443519468],[2945,1742017654]];const APP="\n\nThis digital product was created with AI assistance in design and production, with seller-directed development and review.\n\nSome listing images use AI-assisted mockups. The product previews represent the actual digital files you will receive.";const H=s=>{let h=5381;for(let i=0;i<s.length;i++){h=((h*33)+s.charCodeAt(i))>>>0;}return h;};const ban=(m,c)=>{const d=document.createElement('div');d.style.cssText='position:fixed;top:0;left:0;z-index:99999;background:'+c+';color:#000;font-size:20px;padding:8px';d.textContent=m;document.body.appendChild(d);};const stop=m=>{ban('STOP '+m,'#f99');document.title='STOP';};if(!location.href.includes(ID)){stop('WRONG PAGE');return;}const t=[...document.querySelectorAll('textarea')].find(e=>e.value.length>400);if(!t){stop('NOFIND');return;}const old=t.value;const bi=B.findIndex(p=>old.length===p[0]&&H(old)===p[1]);if(bi<0){stop('BEFORE MISMATCH LEN='+old.length+' HASH='+H(old));return;}if(old.includes('AI assistance')){stop('S1 ALREADY PRESENT');return;}const nv=old+APP;const exp=A[bi];if(nv.length!==exp[0]||H(nv)!==exp[1]){stop('AFTER MISMATCH LEN='+nv.length+' HASH='+H(nv));return;}const st=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,'value').set;st.call(t,nv);t.dispatchEvent(new Event('input',{bubbles:true}));t.dispatchEvent(new Event('change',{bubbles:true}));ban('AFTER OK LEN='+nv.length+' HASH='+H(nv),'#cfc');document.title='AFTER_OK';})()`
- [ ] A 校验  [ ] B 追加核验  [ ] Lee 发布  [ ] 发布后复核

### 3. D4 ADHD-Friendly Planner (4600823259) - 图片句分支：NOEXAMPLE

- 编辑页：https://www.etsy.com/your/shops/me/listing-editor/edit/4600823259#item-details
- 基线文件：live-captures/LIVE-DESC-D4-4600823259-2026-10-23.txt
- 分支依据（英文备查）：M1-M4 are AI desk mockups showing delivered pages in blank state; no filled example (visually checked 2026-10-23)
- 期望 before：LEN=2456 HASH=3967344857（带尾换行变体：LEN=2457 HASH=2073361411，其 after 为 LEN=2701 HASH=713814195）
- 期望 after：LEN=2700 HASH=3104318601
- 阶段 B 脚本：`javascript:(()=>{const ID="4600823259";const B=[[2456,3967344857],[2457,2073361411]];const A=[[2700,3104318601],[2701,713814195]];const APP="\n\nThis digital product was created with AI assistance in design and production, with seller-directed development and review.\n\nSome listing images use AI-assisted mockups. The product previews represent the actual digital files you will receive.";const H=s=>{let h=5381;for(let i=0;i<s.length;i++){h=((h*33)+s.charCodeAt(i))>>>0;}return h;};const ban=(m,c)=>{const d=document.createElement('div');d.style.cssText='position:fixed;top:0;left:0;z-index:99999;background:'+c+';color:#000;font-size:20px;padding:8px';d.textContent=m;document.body.appendChild(d);};const stop=m=>{ban('STOP '+m,'#f99');document.title='STOP';};if(!location.href.includes(ID)){stop('WRONG PAGE');return;}const t=[...document.querySelectorAll('textarea')].find(e=>e.value.length>400);if(!t){stop('NOFIND');return;}const old=t.value;const bi=B.findIndex(p=>old.length===p[0]&&H(old)===p[1]);if(bi<0){stop('BEFORE MISMATCH LEN='+old.length+' HASH='+H(old));return;}if(old.includes('AI assistance')){stop('S1 ALREADY PRESENT');return;}const nv=old+APP;const exp=A[bi];if(nv.length!==exp[0]||H(nv)!==exp[1]){stop('AFTER MISMATCH LEN='+nv.length+' HASH='+H(nv));return;}const st=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,'value').set;st.call(t,nv);t.dispatchEvent(new Event('input',{bubbles:true}));t.dispatchEvent(new Event('change',{bubbles:true}));ban('AFTER OK LEN='+nv.length+' HASH='+H(nv),'#cfc');document.title='AFTER_OK';})()`
- [ ] A 校验  [ ] B 追加核验  [ ] Lee 发布  [ ] 发布后复核

### 4. Savings Full $3 (4598465559) - 图片句分支：NONE

- 编辑页：https://www.etsy.com/your/shops/me/listing-editor/edit/4598465559#item-details
- 基线文件：live-captures/LIVE-DESC-SAVINGSFULL-4598465559-2026-10-23.txt
- 分支依据（英文备查）：images are programmatic flat covers/pin cards and blank page previews; no AI mockups, no filled examples -> product sentence only
- 期望 before：LEN=1154 HASH=1895881291（带尾换行变体：LEN=1155 HASH=2434540469，其 after 为 LEN=1279 HASH=3761565240）
- 期望 after：LEN=1278 HASH=774711758
- 阶段 B 脚本：`javascript:(()=>{const ID="4598465559";const B=[[1154,1895881291],[1155,2434540469]];const A=[[1278,774711758],[1279,3761565240]];const APP="\n\nThis digital product was created with AI assistance in design and production, with seller-directed development and review.";const H=s=>{let h=5381;for(let i=0;i<s.length;i++){h=((h*33)+s.charCodeAt(i))>>>0;}return h;};const ban=(m,c)=>{const d=document.createElement('div');d.style.cssText='position:fixed;top:0;left:0;z-index:99999;background:'+c+';color:#000;font-size:20px;padding:8px';d.textContent=m;document.body.appendChild(d);};const stop=m=>{ban('STOP '+m,'#f99');document.title='STOP';};if(!location.href.includes(ID)){stop('WRONG PAGE');return;}const t=[...document.querySelectorAll('textarea')].find(e=>e.value.length>400);if(!t){stop('NOFIND');return;}const old=t.value;const bi=B.findIndex(p=>old.length===p[0]&&H(old)===p[1]);if(bi<0){stop('BEFORE MISMATCH LEN='+old.length+' HASH='+H(old));return;}if(old.includes('AI assistance')){stop('S1 ALREADY PRESENT');return;}const nv=old+APP;const exp=A[bi];if(nv.length!==exp[0]||H(nv)!==exp[1]){stop('AFTER MISMATCH LEN='+nv.length+' HASH='+H(nv));return;}const st=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,'value').set;st.call(t,nv);t.dispatchEvent(new Event('input',{bubbles:true}));t.dispatchEvent(new Event('change',{bubbles:true}));ban('AFTER OK LEN='+nv.length+' HASH='+H(nv),'#cfc');document.title='AFTER_OK';})()`
- [ ] A 校验  [ ] B 追加核验  [ ] Lee 发布  [ ] 发布后复核

### 5. Savings Starter $1 (4598538460) - 图片句分支：NONE

- 编辑页：https://www.etsy.com/your/shops/me/listing-editor/edit/4598538460#item-details
- 基线文件：live-captures/LIVE-DESC-SAVINGSSTARTER-4598538460-2026-10-23.txt
- 分支依据（英文备查）：same as above (tracker line images are flat typeset)
- 期望 before：LEN=955 HASH=3375102119（带尾换行变体：LEN=956 HASH=4004187537，其 after 为 LEN=1080 HASH=3596814868）
- 期望 after：LEN=1079 HASH=249117226
- 阶段 B 脚本：`javascript:(()=>{const ID="4598538460";const B=[[955,3375102119],[956,4004187537]];const A=[[1079,249117226],[1080,3596814868]];const APP="\n\nThis digital product was created with AI assistance in design and production, with seller-directed development and review.";const H=s=>{let h=5381;for(let i=0;i<s.length;i++){h=((h*33)+s.charCodeAt(i))>>>0;}return h;};const ban=(m,c)=>{const d=document.createElement('div');d.style.cssText='position:fixed;top:0;left:0;z-index:99999;background:'+c+';color:#000;font-size:20px;padding:8px';d.textContent=m;document.body.appendChild(d);};const stop=m=>{ban('STOP '+m,'#f99');document.title='STOP';};if(!location.href.includes(ID)){stop('WRONG PAGE');return;}const t=[...document.querySelectorAll('textarea')].find(e=>e.value.length>400);if(!t){stop('NOFIND');return;}const old=t.value;const bi=B.findIndex(p=>old.length===p[0]&&H(old)===p[1]);if(bi<0){stop('BEFORE MISMATCH LEN='+old.length+' HASH='+H(old));return;}if(old.includes('AI assistance')){stop('S1 ALREADY PRESENT');return;}const nv=old+APP;const exp=A[bi];if(nv.length!==exp[0]||H(nv)!==exp[1]){stop('AFTER MISMATCH LEN='+nv.length+' HASH='+H(nv));return;}const st=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,'value').set;st.call(t,nv);t.dispatchEvent(new Event('input',{bubbles:true}));t.dispatchEvent(new Event('change',{bubbles:true}));ban('AFTER OK LEN='+nv.length+' HASH='+H(nv),'#cfc');document.title='AFTER_OK';})()`
- [ ] A 校验  [ ] B 追加核验  [ ] Lee 发布  [ ] 发布后复核

### 6. Habit Full $3 (4598582424) - 图片句分支：NONE

- 编辑页：https://www.etsy.com/your/shops/me/listing-editor/edit/4598582424#item-details
- 基线文件：live-captures/LIVE-DESC-HABITFULL-4598582424-2026-10-23.txt
- 分支依据（英文备查）：same as above
- 期望 before：LEN=898 HASH=1900152835（带尾换行变体：LEN=899 HASH=2575501421，其 after 为 LEN=1023 HASH=2651436784）
- 期望 after：LEN=1022 HASH=1001372550
- 阶段 B 脚本：`javascript:(()=>{const ID="4598582424";const B=[[898,1900152835],[899,2575501421]];const A=[[1022,1001372550],[1023,2651436784]];const APP="\n\nThis digital product was created with AI assistance in design and production, with seller-directed development and review.";const H=s=>{let h=5381;for(let i=0;i<s.length;i++){h=((h*33)+s.charCodeAt(i))>>>0;}return h;};const ban=(m,c)=>{const d=document.createElement('div');d.style.cssText='position:fixed;top:0;left:0;z-index:99999;background:'+c+';color:#000;font-size:20px;padding:8px';d.textContent=m;document.body.appendChild(d);};const stop=m=>{ban('STOP '+m,'#f99');document.title='STOP';};if(!location.href.includes(ID)){stop('WRONG PAGE');return;}const t=[...document.querySelectorAll('textarea')].find(e=>e.value.length>400);if(!t){stop('NOFIND');return;}const old=t.value;const bi=B.findIndex(p=>old.length===p[0]&&H(old)===p[1]);if(bi<0){stop('BEFORE MISMATCH LEN='+old.length+' HASH='+H(old));return;}if(old.includes('AI assistance')){stop('S1 ALREADY PRESENT');return;}const nv=old+APP;const exp=A[bi];if(nv.length!==exp[0]||H(nv)!==exp[1]){stop('AFTER MISMATCH LEN='+nv.length+' HASH='+H(nv));return;}const st=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,'value').set;st.call(t,nv);t.dispatchEvent(new Event('input',{bubbles:true}));t.dispatchEvent(new Event('change',{bubbles:true}));ban('AFTER OK LEN='+nv.length+' HASH='+H(nv),'#cfc');document.title='AFTER_OK';})()`
- [ ] A 校验  [ ] B 追加核验  [ ] Lee 发布  [ ] 发布后复核

### 7. Habit Starter $1 (4598576567) - 图片句分支：NONE

- 编辑页：https://www.etsy.com/your/shops/me/listing-editor/edit/4598576567#item-details
- 基线文件：live-captures/LIVE-DESC-HABITSTARTER-4598576567-2026-10-23.txt
- 分支依据（英文备查）：same as above
- 期望 before：LEN=918 HASH=3316711530（带尾换行变体：LEN=919 HASH=2077298100，其 after 为 LEN=1043 HASH=3209142455）
- 期望 after：LEN=1042 HASH=107219053
- 阶段 B 脚本：`javascript:(()=>{const ID="4598576567";const B=[[918,3316711530],[919,2077298100]];const A=[[1042,107219053],[1043,3209142455]];const APP="\n\nThis digital product was created with AI assistance in design and production, with seller-directed development and review.";const H=s=>{let h=5381;for(let i=0;i<s.length;i++){h=((h*33)+s.charCodeAt(i))>>>0;}return h;};const ban=(m,c)=>{const d=document.createElement('div');d.style.cssText='position:fixed;top:0;left:0;z-index:99999;background:'+c+';color:#000;font-size:20px;padding:8px';d.textContent=m;document.body.appendChild(d);};const stop=m=>{ban('STOP '+m,'#f99');document.title='STOP';};if(!location.href.includes(ID)){stop('WRONG PAGE');return;}const t=[...document.querySelectorAll('textarea')].find(e=>e.value.length>400);if(!t){stop('NOFIND');return;}const old=t.value;const bi=B.findIndex(p=>old.length===p[0]&&H(old)===p[1]);if(bi<0){stop('BEFORE MISMATCH LEN='+old.length+' HASH='+H(old));return;}if(old.includes('AI assistance')){stop('S1 ALREADY PRESENT');return;}const nv=old+APP;const exp=A[bi];if(nv.length!==exp[0]||H(nv)!==exp[1]){stop('AFTER MISMATCH LEN='+nv.length+' HASH='+H(nv));return;}const st=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,'value').set;st.call(t,nv);t.dispatchEvent(new Event('input',{bubbles:true}));t.dispatchEvent(new Event('change',{bubbles:true}));ban('AFTER OK LEN='+nv.length+' HASH='+H(nv),'#cfc');document.title='AFTER_OK';})()`
- [ ] A 校验  [ ] B 追加核验  [ ] Lee 发布  [ ] 发布后复核

### 8. Budget Full $3 (4598655675) - 图片句分支：NONE

- 编辑页：https://www.etsy.com/your/shops/me/listing-editor/edit/4598655675#item-details
- 基线文件：live-captures/LIVE-DESC-BUDGETFULL-4598655675-2026-10-23.txt
- 分支依据（英文备查）：same as above
- 期望 before：LEN=964 HASH=2019279411（带尾换行变体：LEN=965 HASH=2211711133，其 after 为 LEN=1089 HASH=1230315296）
- 期望 after：LEN=1088 HASH=437706166
- 阶段 B 脚本：`javascript:(()=>{const ID="4598655675";const B=[[964,2019279411],[965,2211711133]];const A=[[1088,437706166],[1089,1230315296]];const APP="\n\nThis digital product was created with AI assistance in design and production, with seller-directed development and review.";const H=s=>{let h=5381;for(let i=0;i<s.length;i++){h=((h*33)+s.charCodeAt(i))>>>0;}return h;};const ban=(m,c)=>{const d=document.createElement('div');d.style.cssText='position:fixed;top:0;left:0;z-index:99999;background:'+c+';color:#000;font-size:20px;padding:8px';d.textContent=m;document.body.appendChild(d);};const stop=m=>{ban('STOP '+m,'#f99');document.title='STOP';};if(!location.href.includes(ID)){stop('WRONG PAGE');return;}const t=[...document.querySelectorAll('textarea')].find(e=>e.value.length>400);if(!t){stop('NOFIND');return;}const old=t.value;const bi=B.findIndex(p=>old.length===p[0]&&H(old)===p[1]);if(bi<0){stop('BEFORE MISMATCH LEN='+old.length+' HASH='+H(old));return;}if(old.includes('AI assistance')){stop('S1 ALREADY PRESENT');return;}const nv=old+APP;const exp=A[bi];if(nv.length!==exp[0]||H(nv)!==exp[1]){stop('AFTER MISMATCH LEN='+nv.length+' HASH='+H(nv));return;}const st=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,'value').set;st.call(t,nv);t.dispatchEvent(new Event('input',{bubbles:true}));t.dispatchEvent(new Event('change',{bubbles:true}));ban('AFTER OK LEN='+nv.length+' HASH='+H(nv),'#cfc');document.title='AFTER_OK';})()`
- [ ] A 校验  [ ] B 追加核验  [ ] Lee 发布  [ ] 发布后复核

### 9. Budget Starter $1 (4598659063) - 图片句分支：NONE

- 编辑页：https://www.etsy.com/your/shops/me/listing-editor/edit/4598659063#item-details
- 基线文件：live-captures/LIVE-DESC-BUDGETSTARTER-4598659063-2026-10-23.txt
- 分支依据（英文备查）：same as above
- 期望 before：LEN=781 HASH=1488512307（带尾换行变体：LEN=782 HASH=1876265885，其 after 为 LEN=906 HASH=540877344）
- 期望 after：LEN=905 HASH=3800727734
- 阶段 B 脚本：`javascript:(()=>{const ID="4598659063";const B=[[781,1488512307],[782,1876265885]];const A=[[905,3800727734],[906,540877344]];const APP="\n\nThis digital product was created with AI assistance in design and production, with seller-directed development and review.";const H=s=>{let h=5381;for(let i=0;i<s.length;i++){h=((h*33)+s.charCodeAt(i))>>>0;}return h;};const ban=(m,c)=>{const d=document.createElement('div');d.style.cssText='position:fixed;top:0;left:0;z-index:99999;background:'+c+';color:#000;font-size:20px;padding:8px';d.textContent=m;document.body.appendChild(d);};const stop=m=>{ban('STOP '+m,'#f99');document.title='STOP';};if(!location.href.includes(ID)){stop('WRONG PAGE');return;}const t=[...document.querySelectorAll('textarea')].find(e=>e.value.length>400);if(!t){stop('NOFIND');return;}const old=t.value;const bi=B.findIndex(p=>old.length===p[0]&&H(old)===p[1]);if(bi<0){stop('BEFORE MISMATCH LEN='+old.length+' HASH='+H(old));return;}if(old.includes('AI assistance')){stop('S1 ALREADY PRESENT');return;}const nv=old+APP;const exp=A[bi];if(nv.length!==exp[0]||H(nv)!==exp[1]){stop('AFTER MISMATCH LEN='+nv.length+' HASH='+H(nv));return;}const st=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,'value').set;st.call(t,nv);t.dispatchEvent(new Event('input',{bubbles:true}));t.dispatchEvent(new Event('change',{bubbles:true}));ban('AFTER OK LEN='+nv.length+' HASH='+H(nv),'#cfc');document.title='AFTER_OK';})()`
- [ ] A 校验  [ ] B 追加核验  [ ] Lee 发布  [ ] 发布后复核

### 10. 2027 Full $3 (4598684850) - 图片句分支：NONE

- 编辑页：https://www.etsy.com/your/shops/me/listing-editor/edit/4598684850#item-details
- 基线文件：live-captures/LIVE-DESC-2027FULL-4598684850-2026-10-23.txt
- 分支依据（英文备查）：same as above
- 期望 before：LEN=1964 HASH=1563019068（带尾换行变体：LEN=1965 HASH=40021702，其 after 为 LEN=2089 HASH=1204725961）
- 期望 after：LEN=2088 HASH=4081145407
- 阶段 B 脚本：`javascript:(()=>{const ID="4598684850";const B=[[1964,1563019068],[1965,40021702]];const A=[[2088,4081145407],[2089,1204725961]];const APP="\n\nThis digital product was created with AI assistance in design and production, with seller-directed development and review.";const H=s=>{let h=5381;for(let i=0;i<s.length;i++){h=((h*33)+s.charCodeAt(i))>>>0;}return h;};const ban=(m,c)=>{const d=document.createElement('div');d.style.cssText='position:fixed;top:0;left:0;z-index:99999;background:'+c+';color:#000;font-size:20px;padding:8px';d.textContent=m;document.body.appendChild(d);};const stop=m=>{ban('STOP '+m,'#f99');document.title='STOP';};if(!location.href.includes(ID)){stop('WRONG PAGE');return;}const t=[...document.querySelectorAll('textarea')].find(e=>e.value.length>400);if(!t){stop('NOFIND');return;}const old=t.value;const bi=B.findIndex(p=>old.length===p[0]&&H(old)===p[1]);if(bi<0){stop('BEFORE MISMATCH LEN='+old.length+' HASH='+H(old));return;}if(old.includes('AI assistance')){stop('S1 ALREADY PRESENT');return;}const nv=old+APP;const exp=A[bi];if(nv.length!==exp[0]||H(nv)!==exp[1]){stop('AFTER MISMATCH LEN='+nv.length+' HASH='+H(nv));return;}const st=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,'value').set;st.call(t,nv);t.dispatchEvent(new Event('input',{bubbles:true}));t.dispatchEvent(new Event('change',{bubbles:true}));ban('AFTER OK LEN='+nv.length+' HASH='+H(nv),'#cfc');document.title='AFTER_OK';})()`
- [ ] A 校验  [ ] B 追加核验  [ ] Lee 发布  [ ] 发布后复核

### 11. 2027 Starter $1 (4598687922) - 图片句分支：NONE

- 编辑页：https://www.etsy.com/your/shops/me/listing-editor/edit/4598687922#item-details
- 基线文件：live-captures/LIVE-DESC-2027STARTER-4598687922-2026-10-23.txt
- 分支依据（英文备查）：same as above
- 期望 before：LEN=876 HASH=814624612（带尾换行变体：LEN=877 HASH=1112808430，其 after 为 LEN=1001 HASH=4134683121）
- 期望 after：LEN=1000 HASH=3519179367
- 阶段 B 脚本：`javascript:(()=>{const ID="4598687922";const B=[[876,814624612],[877,1112808430]];const A=[[1000,3519179367],[1001,4134683121]];const APP="\n\nThis digital product was created with AI assistance in design and production, with seller-directed development and review.";const H=s=>{let h=5381;for(let i=0;i<s.length;i++){h=((h*33)+s.charCodeAt(i))>>>0;}return h;};const ban=(m,c)=>{const d=document.createElement('div');d.style.cssText='position:fixed;top:0;left:0;z-index:99999;background:'+c+';color:#000;font-size:20px;padding:8px';d.textContent=m;document.body.appendChild(d);};const stop=m=>{ban('STOP '+m,'#f99');document.title='STOP';};if(!location.href.includes(ID)){stop('WRONG PAGE');return;}const t=[...document.querySelectorAll('textarea')].find(e=>e.value.length>400);if(!t){stop('NOFIND');return;}const old=t.value;const bi=B.findIndex(p=>old.length===p[0]&&H(old)===p[1]);if(bi<0){stop('BEFORE MISMATCH LEN='+old.length+' HASH='+H(old));return;}if(old.includes('AI assistance')){stop('S1 ALREADY PRESENT');return;}const nv=old+APP;const exp=A[bi];if(nv.length!==exp[0]||H(nv)!==exp[1]){stop('AFTER MISMATCH LEN='+nv.length+' HASH='+H(nv));return;}const st=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,'value').set;st.call(t,nv);t.dispatchEvent(new Event('input',{bubbles:true}));t.dispatchEvent(new Event('change',{bubbles:true}));ban('AFTER OK LEN='+nv.length+' HASH='+H(nv),'#cfc');document.title='AFTER_OK';})()`
- [ ] A 校验  [ ] B 追加核验  [ ] Lee 发布  [ ] 发布后复核

### 12. Restart Weekly Planner + Restart Kit (4600838577) - 图片句分支：DELIVERED

- 编辑页：https://www.etsy.com/your/shops/me/listing-editor/edit/4600838577#item-details
- 基线文件：live-captures/LIVE-DESC-RESTART-4600838577-2026-10-23.txt
- 分支依据（英文备查）：per v1 pack conditional, now confirmed: live-vs-source diff is curly-quote substitution only (don't -> don’t etc.), meaning unchanged; image set includes a filled example page and the download includes a filled example file (verified 2026-10-22). Lee approved live text as baseline 2026-10-23 23:47
- 期望 before：LEN=2629 HASH=380867584（带尾换行变体：LEN=2630 HASH=3978695690，其 after 为 LEN=2910 HASH=1454314175）
- 期望 after：LEN=2909 HASH=2837189813
- 阶段 B 脚本：`javascript:(()=>{const ID="4600838577";const B=[[2629,380867584],[2630,3978695690]];const A=[[2909,2837189813],[2910,1454314175]];const APP="\n\nThis digital product was created with AI assistance in design and production, with seller-directed development and review.\n\nSome listing images use AI-assisted mockups. The product previews represent the actual digital files, and a completed example is included in the download.";const H=s=>{let h=5381;for(let i=0;i<s.length;i++){h=((h*33)+s.charCodeAt(i))>>>0;}return h;};const ban=(m,c)=>{const d=document.createElement('div');d.style.cssText='position:fixed;top:0;left:0;z-index:99999;background:'+c+';color:#000;font-size:20px;padding:8px';d.textContent=m;document.body.appendChild(d);};const stop=m=>{ban('STOP '+m,'#f99');document.title='STOP';};if(!location.href.includes(ID)){stop('WRONG PAGE');return;}const t=[...document.querySelectorAll('textarea')].find(e=>e.value.length>400);if(!t){stop('NOFIND');return;}const old=t.value;const bi=B.findIndex(p=>old.length===p[0]&&H(old)===p[1]);if(bi<0){stop('BEFORE MISMATCH LEN='+old.length+' HASH='+H(old));return;}if(old.includes('AI assistance')){stop('S1 ALREADY PRESENT');return;}const nv=old+APP;const exp=A[bi];if(nv.length!==exp[0]||H(nv)!==exp[1]){stop('AFTER MISMATCH LEN='+nv.length+' HASH='+H(nv));return;}const st=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,'value').set;st.call(t,nv);t.dispatchEvent(new Event('input',{bubbles:true}));t.dispatchEvent(new Event('change',{bubbles:true}));ban('AFTER OK LEN='+nv.length+' HASH='+H(nv),'#cfc');document.title='AFTER_OK';})()`
- [ ] A 校验  [ ] B 追加核验  [ ] Lee 发布  [ ] 发布后复核

## 通用脚本

阶段 A / 发布后复核：`javascript:(()=>{const t=[...document.querySelectorAll('textarea')].find(e=>e.value.length>400);if(!t){document.title='NOFIND';return;}const v=t.value;let h=5381;for(let i=0;i<v.length;i++){h=((h*33)+v.charCodeAt(i))>>>0;}const d=document.createElement('div');d.style.cssText='position:fixed;top:0;left:0;z-index:99999;background:#ff0;color:#000;font-size:20px;padding:8px';d.textContent='CHECK LEN='+v.length+' HASH='+h+' AI='+(v.includes('AI assistance')?'YES':'NO')+' TAIL=['+v.slice(-40)+']';document.body.appendChild(d);})()`

抓取线上描述：`javascript:(()=>{const t=[...document.querySelectorAll('textarea')].find(e=>e.value.length>400);const b=new Blob([t.value],{type:'text/plain'});const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='LIVE-DESC-CAPTURE.txt';a.click();})()`

## 收尾

- 结果回填 DISCLOSURE-FIX-SESSION-PACK 清单 + SESSION-LOG。
- 12 款全完 → 披露修复关闭；品牌故事上线另行约场，不混合。
