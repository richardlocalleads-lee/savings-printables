# 上架场执行单 — 2026-10-24 凌晨（D5 + S-006）

Lee 2026-10-23 23:47 指令：D5、S-006 当晚立即上架（撤销 23:14 顺延）。披露两小点已批准：P1 下一场顺手补回段落空行；Restart 以线上弯引号版为基线、下一场一起追加披露。

## 备料状态（全部就绪）
- 文件包 upload-2026-10-24.zip（21 档）已作聊天附件发 Lee，待他下载+双击解压到 ~/Downloads/upload-2026-10-24/（根目录有新版 xlsx；D5/ 与 S006/ 两子夹；S006 夹内**不含** Start Here——等发布门 4 回填链接后单独传）。
- D5：上架包 d5-build/LISTING-PACK.md（标题/描述含披露两句/13 标签/材料/FAQ 7 条/个人化不开启/5 档说明/图序 M1–M8），价 $4.99。买家档与图在 zip 的 D5/。
- S-006：上架包 s006-build/LISTING-PACK.md（标题/描述含 S1＋如实图片句/13 标签/材料/FAQ 6 条/5 档说明/图序 M1–M5），价 $4.99。图已建成 s006-build/listing-images/（真实渲染＋Example figures 角标）。
- S-006 表格新版：9,645 B，SHA-256 18f8d7d3e5f5a170fd0bccdf8690b4065c4056f839d83e36a734e00d75170e3b（显示层 wrap 修复；公式 0 改动；三场景复算过）。旧版 9,613 B（ea30a1b…）**作废**，Lee Mac Downloads 里的旧 FIXED 档不得使用。

## 场内顺序
1. **D5 上架**（Etsy 新建 listing）：图 M1–M8 → 标题 → 描述（脚本 setter 追加法，整段贴入）→ 类目/属性按编辑器默认引导 → 标签 13 → 材料 → 价格 4.99 → 数字文件 5 档＋逐档说明 → How It's Made（I did / finished product / AI generator）→ 续期 Manual → FAQ 逐条 → 个人化关闭 → **Lee 点 Publish**。发布后回读核对（标题/价格/文件数）。
2. **S-006 发布门**（Lee 22:24 定版，四项全过才上架）：
   - 门1：Lee 亲手把 zip 根目录的新版 Christmas-Countdown-Savings.xlsx（9,645 B）上传店铺 Google 账户（Drive→Sheets 打开）。
   - 门2：在 Sheets 里另建测试副本实测：①漏存填 0 → 后续期次重分摊（$120→$150 型）；②少存一期 → 重分摊；③月薪 1/31 起 → 2/28、3/31 锚定。测完删测试副本，主档保持出货示例值（600/50/2026-10-30/Every 2 weeks/2026-12-24）。
   - 门3：主档开共用「知道链接者可查看」，生成 /copy 形式副本链接并实际打开验证能进建立副本页。
   - 门4：真链接回填 build_s006_print.py 的 LINK_PLACEHOLDER → 重跑生成 Start Here PDF → 核对 PDF 内链接无误 → 单独传 Mac（附件小档）→ 随 listing 上传。
3. **S-006 上架**：同 D5 流程（图 M1–M5、文件 5 档含回填后的 Start Here），**Lee 点 Publish**。
4. 场后：POST-LAUNCH-30D-TRACKER 加两行（D5 及格线见其上架包；S-006 按纲要另记）；当日日志；SESSION-LOG 补披露两小点裁决。

## 纪律提醒
- Etsy 只走 Lee Mac＋香港热点；登录与 Publish 由 Lee 本人；Suggested title 弹窗一律 Dismiss。
- 任一发布门关键项失败 → S-006 本场不上架，D5 不受影响。
- 文件选择窗远程点不动时：先 files.copy 到 Downloads 根目录，再请 Lee 点选。
