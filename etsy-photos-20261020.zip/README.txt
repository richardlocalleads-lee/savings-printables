每个文件夹对应一个 listing，里面的 4 张图是补给该 listing 的额外照片。
在 listing 编辑页的 Photos 区添加即可（首图不动，在后面追加）。
