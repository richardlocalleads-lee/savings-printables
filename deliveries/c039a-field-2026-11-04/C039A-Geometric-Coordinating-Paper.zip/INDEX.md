# C039-A — Small Evergreen Geometric Coordinating Paper Pack

12 seamless digital papers, 3600 x 3600 px (12 inch at 300 dpi), RGB JPG.
Use for card-making, journals, and creative backgrounds: tile, crop, and scale freely.
All 12 share one muted evergreen palette on a warm cream ground, so any main
pairs with any supporting sheet; the suggested pairs below share an accent colour.

## Main patterns (6) — medium density

| File | Pattern | Accent |
|---|---|---|
| C039A-M1-diamond-lattice.jpg | Diamond lattice with terracotta centres and sage points | Ink / terracotta |
| C039A-M2-triangles.jpg | Rows of triangles, sage / terracotta / mustard | Sage / terracotta / mustard |
| C039A-M3-rings.jpg | Teal rings with mustard centres | Teal / mustard |
| C039A-M4-diagonal-stripes.jpg | Diagonal sage bands with a thin terracotta line | Sage / terracotta |
| C039A-M5-hexagons.jpg | Honeycomb hexagon outlines with terracotta centres | Ink / terracotta |
| C039A-M6-scallops.jpg | Scallop arches, teal / sage, mustard apex dots | Teal / sage |

## Supporting patterns (6) — low density, quiet companions

| File | Pattern | Accent |
|---|---|---|
| C039A-S1-dots.jpg | Sparse ink dots | Ink |
| C039A-S2-plus.jpg | Sparse sage plus signs | Sage |
| C039A-S3-grid.jpg | Fine sand grid | Sand |
| C039A-S4-diamonds.jpg | Sparse terracotta diamond outlines | Terracotta |
| C039A-S5-pinstripes.jpg | Sparse diagonal pinstripes, light sage | Light sage |
| C039A-S6-rings.jpg | Sparse teal ring outlines | Teal |

## Suggested pairs (shared accent)

- M1 diamond lattice + S1 dots (ink)
- M2 triangles + S2 plus (sage)
- M3 rings + S3 grid (quiet grid lets the rings lead)
- M4 diagonal stripes + S4 diamonds (terracotta)
- M5 hexagons + S5 pinstripes (quiet sage with ink)
- M6 scallops + S6 rings (teal)

## Files in this pack

- 12 JPGs listed above (3600 x 3600 px, RGB, 300 dpi)
- INDEX.md (this file)
- LICENSE.txt (personal use licence, plain words)

## Notes

- Every sheet is seamless: tile it 2x2, 3x3, or more with no visible join.
- Light grounds throughout, made to be kind to home ink.
- Not certified for fabric printing.
