# Etsy 需求信号候选池 — Settled Days

> 建立：2026-10-22（Lee 批准《每日需求信号扫描》设计，同目录 etsy-daily-demand-scan-DESIGN.md）；2026-10-23 设计升级 v2（身份改为 Settled Days 三生活域、去模具栏、防同质化），S-008 起用 v2 条目格式，S-001～S-007 保留 v1 原文。
> 用途：存放从顾客真实麻烦里发现的新品信号。这里的条目只是「值得再看一眼」，不是推荐、不是立项。
> 隔离：本池条目未经来源级审计，不得与已审计竞品证据（etsy-competitor-scan-2026-10-20.md）混用计数。
> 晋升规则：Lee 点名 → 再议可行性、制作与上架。（2026-10-23 晚 Lee 改：货架核查前置为每条信号入池时的统一附件——有无都报、不筛选、只记在售事实；此前条目中的「未做」是当时的历史状态。）

证据等级（大白话）：
- 硬：已付款买家亲口说的（差评/评价原话）
- 中：多处看到类似说法
- 弱：只看到一处

条目格式（v2，S-008 起）：
`## S-编号 ｜ 日期 ｜ 状态：POOL`（季节急信号加标「急」）
来源 / 顾客原话 / 什么时刻、什么麻烦 / 这件事到底帮他做什么（底层任务）/ 谁被现在市面上的产品排除了 / 生活域：钱·家·心智·其他 / 命中的机会镜头（四方向·三维交叉·买家≠使用者·特殊情境）/ 证据：硬中弱 / 货架核查：<结果>（2026-10-23 晚起每条必做：有＝形态/价格带/评价量级；无＝未发现同类在售＋查处）
（v1 格式含「我们做不做得出来（哪个现成模具、几天）」栏——v2 已删除：可行性是晋升阶段的门，不是发现阶段的筛子。同簇信号只作补充记录追加到原条目下，不占新编号。）

---

## S-001 ｜ 2026-10-22 ｜ 状态：POOL
来源：Etsy 头部 listing「Printable Budget Planner, Weekly Monthly Finance Tracker (PDF A4 A5)」，店铺 phenixprintable（单品 4.8★、368 条评价）。直链：https://www.etsy.com/listing/1363166637/printable-budget-planner-weekly-monthly
顾客原话：Denise（1★，2023-01-02）："I cannot print these the way I want to print them... I basically wasted money on something I will never use." ｜ Rebecs（3★，2026-02-03）："when I try to print it the pages are almost blank, the table... lines are completely invisible... Happy with the pages but not happy when I have to print them" ｜ Ashley（1★，2024-05-04）："...they were not combined together in one PDF. I do not have a way to combine them. I would NOT have purchased had I known this!"
什么时刻、什么麻烦：买完下载回家打印，发现表格线淡得看不见、左右页没拼成一个文件、想双面打印拼不上——打出来的表根本没法用，钱等于白花。
这件产品到底帮他做什么事：让他买来的文件一次打印成功、拿起来就能写字，不用调设置、不用拼文件。
谁被现在市面上的产品排除了：家里只有普通喷墨打印机、或去图书馆打印的人（淡线条在这些打印机上直接消失）；想双面打印省纸的人。现有产品默认"买家会自己调打印设置、会拼 PDF"。
我们做不做得出来：现有模具完全对口——黑白极简本来就是高对比、省墨的；再加"真机打印实测"承诺（普通喷墨＋图书馆激光机都打一遍验）和双面友好排版。约 2–3 天可出一版"一次打印成功"版。
证据：硬（已付款买家亲口说）
货架核查：未做

## S-002 ｜ 2026-10-22 ｜ 状态：POOL
来源：Etsy 头部「Money Saving Challenges Bundle - A6 Printable」，店铺 ThisGirlBudgetsUK（单品 4.8★、338 条评价）。直链：https://www.etsy.com/listing/4310133294/money-saving-challenges-bundle-a6
顾客原话：Reyna（3★，2026-01-27）："I want saving challenges so I don't have to budget and math and it's a fun goal. Having to customize over half of them to my goal... is just too much to me." ｜ Rachelle（2★，2026-09-30）："These are pdfs so you cannot modify them."
什么时刻、什么麻烦：想玩储蓄挑战攒钱，买回来发现一半是空白格——要自己定每个图案值多少钱、自己算总数，等于花钱买回来还要做数学题，乐趣全没了；还有人抱怨 PDF 买回来不能改。
这件产品到底帮他做什么事：让他不动脑子、照着涂格子就把钱攒下来；想改的人能直接在文件里改。
谁被现在市面上的产品排除了：怕麻烦、"懒得做"的人——现有产品默认买家愿意自己设金额、做算术。
我们做不做得出来：现有模具出"金额预填版"（每格多少钱标好、总数算好）约 1–2 天；再顺手出可填写版（fillable PDF）回应"PDF 不能改"的抱怨。
证据：硬（已付款买家亲口说）
货架核查：未做

## S-003 ｜ 2026-10-22 ｜ 状态：POOL
来源：Reddit r/povertyfinance 帖《I think budgeting is broken for people paid biweekly—am I wrong?》（u/jackyo2007，2026-03-21）及同帖评论。直链：https://www.reddit.com/r/povertyfinance/comments/1rzqqly/i_think_budgeting_is_broken_for_people_paid/
顾客原话：发帖人 "most budgeting advice and apps are set up for people who get paid monthly, but that's not how it works for a lot of us." ｜ 评论 u/ladysig220："I got a monthly planner. I note the due dates of every bill on the planner, and also when my paychecks are deposited."
什么时刻、什么麻烦：双周发工资的人用按月设计的预算工具处处别扭——账单到期日和工资到账日对不上，只好买纸质本子手写，把每笔账单和每次工资到账日一个个对上，看哪笔账从哪张工资里扣。
这件产品到底帮他做什么事：让他一眼看清"每一笔账单从哪一次工资里出"，不用自己手写对照。
谁被现在市面上的产品排除了：双周薪、周薪、收入不固定的人——现有产品默认"每月发一次工资"。
我们做不做得出来：我们已经在卖双周薪预算表（Biweekly Paycheck Budget Planner）；模具可再出"账单到期×工资到账对照页"单页，约 1–2 天。
证据：中（同一帖子里发帖人＋多位评论者同类说法；非付款买家）
货架核查：未做

## S-004 ｜ 2026-10-22 ｜ 状态：POOL
来源：Reddit r/ADHD 两帖——《How do you budget when your brain doesn't want to?》（u/dragon_building，2026-06-14）直链 https://www.reddit.com/r/ADHD/comments/1u5hrz5/how_do_you_budget_when_your_brain_doesnt_want_to/ ＋《ADHD Friendly Budgeting Apps (free)》（u/locoweed0923，2025-12-29）直链 https://www.reddit.com/r/ADHD/comments/1pyewp8/adhd_friendly_budgeting_apps_free/
顾客原话："In a way that's not a boring spreadsheet that drives me crazy to look at more than once" ｜ "Are there really no basic apps for this? I downloaded a few, but my brain wires immediately hiss and crawl away from them." ｜ 评论 u/AryaStormborn13："When Mint died, I ended up building my own tool in Airtable rather than fighting the not-quite-right features in various apps"
什么时刻、什么麻烦：注意力难集中的人打开预算表或记账 app——分类太多、表格太密，看第二遍就崩溃，干脆放弃；有人被逼到自己在 Airtable 里搭工具。
这件产品到底帮他做什么事：给他"一眼看懂、不用学、打开就能用"的极简预算页，一页只回答一件事（比如"今天还能花多少"）。
谁被现在市面上的产品排除了：注意力困难人群——现有产品默认用户有耐心学系统、填几十个分类。
我们做不做得出来：黑白极简模具天然对口"低刺激"；做"一页一件事"极简版约 2–3 天。
证据：中（两个帖子＋评论，多人同类说法；非付款买家）
货架核查：未做

## S-005 ｜ 2026-10-22 ｜ 状态：POOL
来源：Reddit r/budget 帖《Budget methods/apps that are hard to make overly complicated suggestions》（u/mell19995，2021-11-01）。直链：https://www.reddit.com/r/budget/comments/qkbq0g/budget_methodsapps_that_are_hard_to_make_overly/
顾客原话："I'm the person who if given a spreadsheet will then proceed to add as many formulas to it that I think makes it easier but in reality just makes it harder"
什么时刻、什么麻烦：拿到电子表格就忍不住加公式、加分类，最后复杂到看不出任何行动价值——工具本身成了负担。
这件产品到底帮他做什么事：给他一个"想搞复杂都搞不起来"的预算页，结构锁死、只填数字。
谁被现在市面上的产品排除了：同 S-004，注意力/执行功能弱、容易把系统玩崩的人。
我们做不做得出来：与 S-004 同一方向（"极简低刺激"线），现有模具约 2–3 天。
证据：弱（只看到这一处）
货架核查：未做

## S-006 ｜ 2026-10-23 ｜ 状态：POOL ｜ 急
来源：Mumsnet 讨论帖《How are people budgeting for Christmas with rising costs this year?》（101 条回复，2026-09-23 发起）https://www.mumsnet.com/talk/christmas/5581611-how-are-people-budgeting-for-christmas-with-rising-costs-this-year ＋ Retail Week 转引 Affirm 零售调查（2026-10-14）https://www.retail-week.com/customer/third-of-shoppers-start-christmas-early-in-longer-golden-quarter-data-shows/7052334.article ＋ TD Bank 年度假日购物调查（2026 年）https://stories.td.com/us/en/article/td-banks-annual-survey-reveals-holiday-shoppers-this-year-plan-to-trim-spending-avoid-overspending ＋ Giftster Holiday Shopping Index（2026-08）
顾客原话：Hotmessmum31（发帖人）："Has anyone started saving a certain amount each week or month until nearer to December? Would love to know everyone thoughts as I am feeling financially pressured this year." ｜ IDontCareWhatMyUsernameIs："This year I've done the Monzo challenge which saves 1p on January 1st, then it goes up by 1p each day. I have had to pause it sometimes if I'm skint before payday, but I've got to about £350. Not enough for everyone but enough for the kids. The adults will have to go without sadly!" ｜ Jellybunny98："Work out how much you spend, divide by 12 and put that amount into a savings pot each month." ｜ Affirm 调查（经 Retail Week）："Of those planning to start their festive shopping earlier, almost half (47%) said they were doing so to spread the cost across several paydays." ｜ TD Bank 调查："22% are setting aside extra money in advance of the holidays."
什么时刻、什么麻烦：10 月底离圣诞不到 9 周，很多人年初没存下圣诞钱，现在才慌——手头没有一笔圣诞款，只好靠土办法凑（Monzo 的 1p 每日挑战、现金信封、另开一个储蓄账户），心里没底"每个工资日到底要存多少才够"，而且手头紧时计划就断了（"if I'm skint before payday"）。
这件产品到底帮他做什么事：给他一个"从现在到圣诞的倒计时储蓄页"：填总金额＋发工资频率，算好"还剩几次工资、每次工资日存多少"，断了也能接着来，不用从头再算。
谁被现在市面上的产品排除了：没能从 1 月 1 日开始存的人——市面上的 52 周/1p 储蓄挑战默认从 1 月 1 日开局（"saves 1p on January 1st, then it goes up by 1p each day"），10 月底才想起来的人根本用不上；还有发工资前就手头紧、计划会断的人。现有产品的默认假设是"年初就有计划"。
我们做不做得出来：黑白极简储蓄模具现成，做"圣诞倒计时储蓄单页"（填目标金额＋工资日频率→每份存多少的除法表预填＋"断了接着来"宽容行）约 1–2 天。注意：本店已有圣诞预算包（引流型 $2.99），这张单页可当配套、不抢它的位置。
证据：中（Mumsnet 同帖多人口吻 ＋ Affirm/TD Bank 零售调查数字佐证同一麻烦；非付款买家）
货架核查：未做

## S-007 ｜ 2026-10-23 ｜ 状态：POOL
来源：澳洲 Carer Gateway 论坛帖《I always seem to spend more than I planned to at this time of year! Just thinking about some money saving ideas now, any tips?》https://forum.carergateway.gov.au/s/question/0D5Oa00000PN8jJKAT/i-always-seem-to-spend-more-than-i-planned-to-at-this-time-of-year-just-thinking-about-some-money-saving-ideas-now-any-tips
顾客原话：一位回复者："When this is all over it'll be back to putting $10-$20 away each week in a savings account."
什么时刻、什么麻烦：每年圣诞过后都懊悔——"今年又超支了"，发誓"明年我要从头开始，每周固定存一点"。但这个决心只在 12 月底–1 月初最烫，拖几周就凉了。
这件产品到底帮他做什么事：在她懊悔最烫的那一刻，递给她一张"明年圣诞从 1 月 1 日第一天就开始"的每周小额储蓄表，让决心立刻变成一个能打印出来贴冰箱的计划，而不是一句空话。
谁被现在市面上的产品排除了：怕"错过开局"的人——52 周挑战默认 1 月 1 日起步，1 月中旬才看到产品的人会觉得"已经输了"；现有产品没有"晚了也没关系、从这周补起"的入口。
我们做不做得出来：黑白极简储蓄挑战模具完全对口，约 1 天。时机注意：购买高峰在 12 月底–1 月初，现在入池是提前埋弹药。
证据：弱（只看到这一处）
货架核查：未做

## S-008 ｜ 2026-10-23 ｜ 状态：POOL
来源：英国学生论坛 The Student Room 帖《Has anyone tried TSR's new Study Planner?》https://www.thestudentroom.co.uk/showthread.php?t=2492804（注：主帖为十余年前的老帖，麻烦本身常青，如实标注）
顾客原话：用户 theJdog："why would I want to do a whole day of Chem revision when I have an exam coming up for Psychology the next day???" ｜ "when the exam is over for one subject, it will still have those subjects written ... when I don't need to even do any revision for that damn subject because I've done the exam." ｜ 同帖用户 JWM14："It doesn't take 10 minutes breaks in to consideration, it doesn't spread out the times as I want to do 4 hours a day but not all in one go, how do I spread it out?"
什么时刻、什么麻烦：考试季手里好几门考试、日期各不相同。复习计划工具不会按考试日期排——明天考心理学，它安排你今天复习一整天化学；化学考完了，它还天天提醒你复习一门已经考完的课。学生只能一格一格手动挪，嫌麻烦就直接弃用。
这件事到底帮他做什么：输入每门课的考试日期，自动把"复习哪门"铺到考试前的每一天——离考试越近的科目越优先，考完的科目自动退场，不用手动挪。
谁被现在市面上的产品排除了：考试撞期、需要按"远近"动态排的学生。现有 planner 默认固定模板排期，不懂"考试近了就专攻那门"这个人之常情。
生活域：心智（学习场景·考前复习排期）
命中的机会镜头：高价值问题（考试临近、紧迫、容错低）＋时间窗口（考试季）；三维交叉：时间（考前数周）×人群情境（多门考试撞期的学生）×支付动机（怕挂科、花小钱换"不用自己手动挪"）
证据：中（同一论坛多名学生抱怨同类问题；主帖年代久远，已如实标注）
货架核查：未做

## S-009 ｜ 2026-10-23 ｜ 状态：POOL
来源：同上帖 https://www.thestudentroom.co.uk/showthread.php?t=2492804（十余年前老帖，如实标注）
顾客原话：用户 Hanxa："Trying to use the study planner, but the subject options are severely lacking. There should be an 'Other' option for people on different courses so we can type in our own subject title." ｜ "to see how I am doing compared to the suggestions on the study planner, and where I can manage my time more efficiently with work as well as uni." ｜ 同帖用户 ellsie98："I love it! However, would it be possible to add the FSMQ Additional Maths? ... at the moment, I just have it set as GCSE Maths with a different exam date."
什么时刻、什么麻烦：上了大学想用学习 planner，科目下拉列表里只有中学生的固定科目，自己的专业模块根本填不进去，只能瞎填一个凑合。更麻烦的是大学生还要打工，planner 里没地方排班次，看不了"学习加打工时间到底够不够"，最后回去用纸笔和谷歌日历凑合。
这件事到底帮他做什么：把"我这学期实际上的课/模块＋打工班次"排进一周，一眼看到时间到底够不够用、哪里还能挤。
谁被现在市面上的产品排除了：大学生（模块制课程）、半工半读的学生、考特殊证书的人。现有产品默认"全世界都只有 GCSE/A-Level 那几门固定科目"。
生活域：心智（学习场景·大学生学期排期）
命中的机会镜头：细分人群与特殊情境（半工半读的大学生——被默认假设排除的生活形态）＋大众常青（每学期开学都来一遍）
证据：中（同帖两名用户抱怨科目覆盖不足；年代已标注）
货架核查：未做

## S-010 ｜ 2026-10-23 ｜ 状态：POOL
来源：Etsy "Study Planner 2024" market 页买家评价，用户 Trinity W（5 星评价中的实质抱怨）http://etsy.com/ca/market/study_planner_2024?ref=lp_queries_internal_bottom-11
顾客原话："excellent!!! Perfect planner for excel. Ended up having to get a physical planner bc I needed space for other things besides deadlines and I couldn't figure out how on here (I am tech illiterate at times), but I love it for deadlines!!!!"
什么时刻、什么麻烦：学生在 Etsy 买了电子表格版的学习 planner，开学后发现它只够记截止日期；想加"截止日期之外的东西"（其他事项、笔记空间）时，对着表格改不来——自认"有时候不太懂技术"。最后又花钱去买了一本纸质 planner，为同一需求付了两次钱。
这件事到底帮他做什么：一份不用学表格操作、打开就能同时记"截止日期"和"杂事笔记"的学习计划，不逼用户自己改表。
谁被现在市面上的产品排除了：自认"不太懂技术"的学生。电子表格类产品默认"用户会自己改表加列"，把这群人排除在外。
生活域：心智（学习场景·学习计划工具）
命中的机会镜头：细分人群与特殊情境（技术不自信的学生——被默认假设排除的人群）
证据：硬（Etsy 已付款买家亲口说；虽为 5 星评价，抱怨实质：为同一需求付了两次钱）
货架核查：未做

## S-011 ｜ 2026-10-23 ｜ 状态：POOL
来源：园艺论坛 TheEasyGarden 帖《Can't seem to get organized. What seeds should I be starting now?!》https://www.theeasygarden.com/threads/cant-seem-to-get-organized-what-seeds-should-i-be-starting-now.9889/（注：2011 年老帖，麻烦常青，如实标注）
顾客原话：发帖人 Wendy："It seems that I'm always saying, 'I should have planted more [insert whatever I'm harvesting]' but of course it's always too late to start more NOW." ｜ "I can't seem to get organized enough to get the seeds started at the right time." ｜ "Does anyone grow (nearly) year round, and how do you keep track of what to start when?" ｜ 回帖自凑土办法："Take a calendar or draw one, use the catalog and mark last frost date." / "wrote everything down on a little schedule as far as when to start what seeds (determined by counting back the weeks from average last frost in the spring)" / "started keeping a garden journal and write down when I planted, when it sprouted... so I don't repeat them"
什么时刻、什么麻烦：每年播种季，想自己种菜吃的人总在错过时机——收获时才后悔"当初多种点就好了"，可那时再播已经太晚；随手播六棵这个、六棵那个，收下来一星期就吃完，填不满冰箱也存不下过冬。网上的播种月份表是通用版，跟自己当地的霜冻时间对不上，不知道"现在到底该播什么、播多少"。
这件事到底帮他做什么：输入"我住哪儿（当地最后霜冻日）＋想种什么、想吃多少"，算出每种菜现在该不该播、该播多少棵才够吃/够存。
谁被现在市面上的产品排除了：新手和自给型种菜者。现有内容默认"你知道自己当地的霜冻日、会看种子包装上的周数自己倒推"，把不会算的人排除在外。
生活域：其他（园艺手工·种菜播种排期）——三主场之外的新领域
命中的机会镜头：时间窗口（播种季一年就那几周，错过等一年）＋细分人群与特殊情境（新手自给种菜者）
证据：弱（只看到这一个帖子；但帖内多条回帖共鸣＋三种自凑土办法；年代已标注）
货架核查：未做

## S-012 ｜ 2026-10-23 ｜ 状态：POOL
来源：Mumsnet 帖《Moving house - what do you wish you had thought about re: moving day?》（20 条回复）https://www.mumsnet.com/talk/property/904542-Moving-house-what-do-you-wish-you-had-thought-about
顾客原话：penona："Keep your phone charger handy. ... Keep some loo roll out! (and a hand towel and soap). Keep the cleaning stuff handy - our place was filthy when we moved in so couldn't start unpacking until clean." ｜ theITgirl："Essential to have one room looking normal to relax in, if you are surrounded by boxes you will not be able to relax." ｜ bran："There's nothing worse than having a screaming exhausted child and making him wait while you find the bedlinen and put it on."
什么时刻、什么麻烦：搬家当天和头几个晚上——充电器、床单、餐具、厕纸全在箱子里翻不出来；新家脏得没法开箱；孩子累到尖叫还要等你找床单。所有力气都花在"翻箱子找东西"上，没人教你先干哪件。
这件事到底帮他做什么：在混乱中按优先级恢复基本生活秩序——先让一间屋子能住人、先把今晚和明天早上要用的东西找出来，而不是按房间顺序慢慢开箱。
谁被现在市面上的产品排除了：带小孩的家庭（现有搬家清单默认成年人搬家）；自己动手搬、没请搬家公司的人；租客（搬进去房子可能是脏的，得先清洁才能开箱）。
生活域：家（搬家·搬家当天与头 72 小时）
命中的机会镜头：大众常青（搬家是高频生活事件）；三维交叉：时间（搬家当天＋头 72 小时）×人群情境（带孩子的家庭、自己动手搬家者）×支付动机（花小钱换第一晚不崩溃）；特殊情境：带幼儿家庭
证据：中（同一帖内 5 位妈妈同类说法；另有多篇搬家媒体文章讲 first-night box，佐证这是公认痛点）
货架核查：未做
补充记录（远征 2026-10-23，YouTube 评论区佐证）：Clutterbug《The BEST House Moving Tips》评论区（1,416 条评论）多人同类——@adrml4536："Watching this the week before bc I didn't know where to start"（搬家前一周看这个，因为根本不知道从哪下手）；@JasonAllison-er2dj："I had all of my granddaughters Christmas in a black garbage bag and it got mixed up with garbage and I found myself having to re buy everything a few days before Christmas."（圣诞礼物装黑垃圾袋被当垃圾扔了，圣诞前几天全部重买——打包无系统的代价）；@alexandrapappworth1149："I needed to hear that feeling overwhelmed is normal!" https://www.youtube.com/watch?v=-2pJm8ifemc

## S-013 ｜ 2026-10-23 ｜ 状态：POOL
来源：AgingCare 论坛帖（26 条回答）https://www.agingcare.com/questions/what-do-i-do-with-belongings-that-cant-go-to-assisted-living-470675.htm?orderby=oldest
顾客原话：发帖人："My Mom is moving to assisted living and has lots of stuff that can't go with her. How do I keep family from potentially acting like vultures to take what is left? ... I want to do what is fair for everyone" ｜ Daughterof1930："One of the early things I did was change the locks on my parent's home, exactly to deter some family vultures." ｜ Midkid58："My OB vultured through my gma's condo and stripped it bare before mother even had a chance to take inventory."
什么时刻、什么麻烦：妈妈要搬进辅助生活机构，一屋子东西带不走。负责的那个子女一边要赶在期限前清掉房子，一边防着亲戚像秃鹫一样先下手拿走值钱的，还要让每个兄弟姐妹都觉得"分得公平"，不然亲情翻脸。
这件事到底帮他做什么：替全家定一个"分东西"的公平流程——谁先挑、怎么轮流、哪些留作念想、哪些卖掉、卖的钱记到哪，让事后没人翻旧账。
谁被现在市面上的产品排除了：住在外地的兄弟姐妹（到不了现场，只能靠人拍照、替他留东西）；多子女家庭（现有整理产品默认一个人说了算）。
生活域：家（照顾父母·父母搬迁后物品分配）
命中的机会镜头：细分人群与特殊情境（多子女家庭、异地子女）＋高价值问题（复杂、易出错、伤感情）；买家≠使用者：子女替父母/替全家买；特殊情境：共同照护分工、异地
证据：中（同一帖 26 条回答多人同类做法；另有英国 Alzheimer 论坛同类讨论佐证）
货架核查：未做

## S-014 ｜ 2026-10-23 ｜ 状态：POOL
来源：英国 Alzheimer's Society 论坛帖 https://forum.alzheimers.org.uk/threads/clearing-stuff-out-of-the-house.119025/
顾客原话：#7："Clearing my Mum's house took months... photos (thousands of them from the days when people had printed photos!) that took hours and hours simply becasue of the conversations they started - thay are now mostly in a big box in our house - stll not sorted."（原文拼写照录）｜ #8："we got one of the charities who do house clearances to do it. We went through things first decided what we each wanted then the charity came and took everything away."
什么时刻、什么麻烦：清妈妈的房子花了好几个月。最难的不是搬东西，是每一件都勾起回忆、根本做不了"留还是扔"的决定。几千张老照片光是翻看就花了好几个小时，最后装进大箱子搬回自己家——到现在还没整理完；还怕扔错别人有感情的东西。
这件事到底帮他做什么：帮悲伤中的人把"做决定"这件事变小、变快——一次只决定一件，允许"以后再定"，不逼自己当场扔，也不替家人扔。
谁被现在市面上的产品排除了：丧亲后情绪还没缓过来的人（现有整理产品默认理性高效）；大家庭（怕扔错别人有感情的东西，没人敢拍板）。
生活域：家（照顾父母·丧亲后清屋）
命中的机会镜头：细分人群与特殊情境（丧亲清屋）＋高价值问题（情绪重、怕后悔、易冻结）；买家≠使用者：子女替已故父母处理
证据：中（同一论坛帖内多人；另有同类说法佐证）
货架核查：未做
去重备注：与 S-013 同属"清父母房子"大主题，但底层任务不同——S-013 是"兄弟姐妹之间怎么分才公平"的流程问题，本条是"悲伤中做不了决定"的情绪冻结问题，不合并。

## S-015 ｜ 2026-10-23 ｜ 状态：POOL
来源：JustAnswer 英国交通法问答帖（真实求助者提问）https://www.justanswer.co.uk/traffic-law/miy57-moved-address-forgot-change-v5c.html
顾客原话：提问人："I have moved address and forgot to change the v5c but changed driving licence address. ... my vehicle was not taxed from Nov 22 and given results from the court in June 23 saying I need to pay £409 for keeping a vehicle which does not meet insurance requirements." ｜ "I didn't realise the car needed to be insured if I'm not driving it" ｜ "I'm low on money right now" ｜ 同页另两起同类提问："I moved a bit after and didn't see any pcn. I updated driving licence address but forgot to update v5c" / "In October 2021 I moved address I updated my driving license etc but forgot to update my v5c logbook…"
什么时刻、什么麻烦：搬了家，以为改了驾照地址就完事了，车辆登记（v5c）忘改。警告信全寄到旧地址没收到，最后变成法庭罚单 £409。对行政流程不熟、或"以为改一处就够了"的人最容易中招。
这件事到底帮他做什么：搬家后把新地址同步给所有机构，一处不漏、有记录可查——而不是靠脑子记住"还有谁没通知"。
谁被现在市面上的产品排除了：以为"改一处就够了"的人（现有清单默认你知道每件事要单独通知）；对行政流程不熟的人。
生活域：家（搬家·搬家后行政）
命中的机会镜头：大众常青（搬家行政是每次搬家的固定麻烦）＋高价值问题（忘一次就罚几百镑）；三维交叉：时间（搬家后 2–4 周行政窗口）×人群情境（独自处理搬家行政的人）×支付动机（花小钱避开几百块罚款）
证据：中（同一页面 3 起"改了驾照忘改 v5c"同类案例；Mumsnet 帖 "Make sure you do a post redirection" 佐证；move.org "Mail forwarding only lasts a year, so if you fail to do so, your mail might eventually get lost in transit." 佐证）
货架核查：未做

## S-016 ｜ 2026-10-23 ｜ 状态：POOL
来源：西班牙女性论坛 WeLoverSize 两帖互证——①《Ganamos lo mismo pero yo no llego a fin de mes》（发帖人 Yusita，2026-10-21，15 条回复）https://weloversize.com/topic/ganamos-lo-mismo-pero-yo-no-llego-a-fin-de-mes/ ＋ ②《¿es normal que de por hecho que lo pago todo yo?》（发帖人 Davinia，2026-09-30，20+ 条回复）https://weloversize.com/topic/es-normal-que-de-por-hecho-que-lo-pago-todo-yo/
顾客原话：Yusita："hay una lista de cosas que en nuestra casa se pagan «a medias» pero que en la práctica caen siempre de mi lado"（家里有一堆名义上"对半"、实际上回回落到我头上的开销）｜ "Pero es que llevo la cuenta porque si no la llevo yo no la lleva nadie"（这个账我不记就没人记，可月底手头紧的总是我）｜ "No sé cómo abrir esta conversación sin que suene a acusación."（我不知道怎么开口谈这事才不像在指责他）｜ 评论 AveFénix："detalles tontos 'fuera' de los gastos oficiales que me están quitando capacidad de ahorro"（那些"官方账本之外"的小钱，正在吃掉我的储蓄能力）｜ Davinia："pequeños gastos que van apareciendo, sin que exista una conversación clara sobre cómo repartirlos"（那些不断冒出来的小开支，从来没有好好谈过到底怎么分）｜ 自凑土办法：CuentaComún 建议"se define una media de gastos mensuales, se mete un margen de 100 o 200€ de imprevistos"（定一个共同账户，每月留 100–200 欧机动额度）；1234 建议"que te haga un bizum enseguida con su parte"（你垫付的，他那份立刻转账还你）。
什么时刻、什么麻烦：同居情侣/夫妻，工资一样、名义上开销对半。房租水电这些"大账"分得清清楚楚，但他家人的生日礼物、家里用完要补的日用品、看病停车费、聚餐要带的东西——这些"账本之外"的小钱回回都是她在付。月底他有钱存，她却要盯着手机银行过日子。她还不敢开口，因为一谈钱就像在"记账比赛"、像在指责对方。
这件事到底帮他做什么：让两个人共同生活里那些"没进任何账本、也没人认领"的小钱现形、公平分摊——而且是以一种不把感情谈成算账的方式。
谁被现在市面上的产品排除了：没有共同账户、靠"各付各的"过日子的伴侣——记账工具默认"一个人的预算"或"正式的共同账户"，没人管"账本之外的小钱"；更排除了"怕一谈钱就伤感情"的人，现有产品默认用户敢理直气壮地算账。
生活域：钱（家庭共同开支·伴侣分账）
所属语区：西班牙语区（西班牙本地论坛，2026-10）
命中的机会镜头：细分人群与特殊情境（无共同账户、靠非正式分摊过日子的同居伴侣——被默认假设排除的生活形态）＋大众常青（每月月末都来一遍）；三维交叉：时间（月末手头紧）×人群情境（同居情侣/夫妻、无共同账户）×支付动机（花小钱换"不是我乱花钱"的清白＋公平感）；买家≠使用者：无（自用）
证据：中（两个独立帖子、不同发帖人、相隔三周，20 余条评论同类说法；非付款买家）
货架核查：未做
去重备注：与池内 S-003（账单到期日×工资到账日对不上）不同——那条是"时间对不上"，这条是"钱没进账本、被一个人默默扛了"，底层任务不同，不合并。

## S-017 ｜ 2026-10-23 ｜ 状态：POOL
来源：西班牙女性论坛 WeLoverSize 帖《No quiero pagar la cuenta de restaurante a medias》（发帖人 Cloe，2026-10-20，29 条回复）https://weloversize.com/topic/no-quiero-pagar-la-cuenta-de-restaurante-a-medias/
顾客原话：Cloe："no tengo por qué pagar ni las cervezas de nadie ni las copas que se tomen nadie porque además son un pellizco"（我凭什么替别人的啤酒和酒买单，那可不是小数目）｜ "Es algo que luego en la cuenta se nota un montón y que perfectamente me la sube 10 o 15 euros más."（结账时差得非常明显，一顿饭能让我多付 10 到 15 欧元）｜ "no estoy pidiendo que me paguen el postre estoy pidiendo pagar lo que yo me como y nada más"（我不是要人请我吃甜点，我只想为自己吃的那份付钱，仅此而已）｜ 评论 Didí："Quince pavos de más es un menú completo."（多付的 15 欧元就是一整份套餐的钱）｜ 自凑土办法：Isa 建议"pones encima de la cuenta el dinero de lo que tú has consumido y decir: esto es lo mío"（把属于你那份的钱直接放账单上，说"这是我的"）；Pikolina 建议开席前先声明只付自己的饮料和甜点，"lo pagas en efectivo o haces bizum"（现金或即时转账）。
什么时刻、什么麻烦：跟男友一大家子聚餐，"都是一家人"所以永远 AA。她只喝水/可乐，别人人均两三杯啤酒加餐后酒，一顿饭她要多付 10–15 欧。想只付自己的，又怕被说"小气"、怕破坏家庭规矩，男友还不肯替她开口。
这件事到底帮他做什么：在群体聚餐的社交压力下，只为自己实际消费的那部分付钱——不用当众算小账、不用吵架。
谁被现在市面上的产品排除了：聚餐里消费少的人（不喝酒的、吃得少的）、被"老规矩"绑住的外来者。分账工具默认"大家 AA"或默认有人敢站出来算账，把"不想显得小气"的人排除在外。
生活域：钱（社交聚餐分账）
所属语区：西班牙语区（西班牙本地论坛，2026-10）
命中的机会镜头：细分人群与特殊情境（聚餐中消费明显少的人——被"AA 默认公平"假设排除）＋大众常青；三维交叉：时间（每次聚餐结账时刻）×人群情境（与伴侣家人/朋友聚餐的"外来者"）×支付动机（花小钱换"不多付冤枉钱、又不丢面子"）
证据：中（同一帖内发帖人＋多位评论者同类经历与土办法；非付款买家）
货架核查：未做
去重备注：与 S-016 相邻但底层任务不同——S-016 是"家里账本之外的小钱被一个人默默扛"，这条是"饭桌上 AA 制让消费少的人多付钱"，一个是私下持续、一个是公开即时，不合并。
## S-018 ｜ 2026-10-23 ｜ 状态：POOL ｜ 来源：远征 2026-10-23
来源：AgingCare 论坛两帖——《Is there anyone who can help a caregiver whose siblings don't help?》https://www.agingcare.com/questions/is-there-anyone-who-can-help-a-caregiver-whose-siblings-dont-help-440655.htm?orderby=oldest ＋《How do you deal with depression and being burnt out as a caregiver who gets no help from siblings?》https://www.agingcare.com/questions/how-do-you-deal-with-depression-and-being-burnt-out-as-a-caregiver-who-gets-no-help-from-siblings-471040.htm?orderby=oldest ＋ Reddit r/CaregiverSupport 两帖——《Am I the only one not getting Sibling support?》https://www.reddit.com/r/CaregiverSupport/comments/1wi8veu/am_i_the_only_one_not_getting_sibling_support/（2026-09）＋《Being a caregiver for my parents when I have siblings who refuse to help is ruining my life》https://www.reddit.com/r/CaregiverSupport/comments/1rj8071/being_a_caregiver_for_my_parents_when_i_have/（2026-03）
顾客原话：AgingCare 发帖人："I'm the only one who now caring for my mother 87yr old. All of them stress me out, all mouth no help. Can't stay, haven't stayed with my mother 24/7 not even 2 weeks to give me a break."（87 岁的母亲只有我在照顾。他们只会让我更累，光说不做。连让我歇两周都不行。）｜ AgingCare 回帖："I do everything! I myself am living with MS, experiencing terrible hot flashes, working full time and trying to move us both to a better, safer healthier environment."（什么都是我一个人干！我自己还患有多发性硬化症，潮热严重，还要全职工作。）｜ Reddit 发帖人："My siblings live locally, but I am the one doing all the hands-on work. They will text me things like 'thank you for all you do,' but they never actually step in or offer real help."（兄弟姐妹就住附近，但动手的事全是我。他们只会发短信说谢谢，从不搭把手。）｜ Reddit 评论 u/Lulu_531："I took 16 years off for caregiving. I am 54 and have been trying to get a full time job for two years. I can't get hired."（我为照护脱产 16 年，现在 54 岁找了两年工作，没人要我。）｜ YouTube（Pamela D Wilson《How to Deal With Deadbeat Siblings》评论区）@debby891（62 赞）："I've been caring for my mom for 5+ years, 24/7, three siblings who I have asked, begged, pleaded asking for a break. Their answer..we are going to live our lives so not a single day off in 5 years."（我 24 小时照顾我妈 5 年多了，求过三个兄弟姐妹无数次让我歇一下。他们的回答是"我们要过自己的生活"——5 年里一天都没歇过。）｜ @georginamuns44（39 赞）："I have 5 siblings 3 of them live minutes away from my dad's apartment... the never call, never come.. they just don't care"（5 个兄弟姐妹，3 个就住几分钟外，从不打电话、从不来，就是不在乎。）｜ @anamore8："How about a sibling who is local but won't help because it's the daughters responsibility. He's the son and it's not his job."（兄弟住附近但不帮忙，因为"这是女儿的责任"，他是儿子不是他的活。）
什么时刻、什么麻烦：父母失能后，四五个子女中只有一个人扛下全部照护——其他人住得不远也不搭手，顶多发短信说谢谢。扛的人 24 小时连轴转，连两周喘息都换不来，自己还可能有病在身、还要全职工作；长期下来 burnout、抑郁，甚至脱产十几年后重返职场无门。
这件事到底帮他做什么：让独自扛照护的人有一个"喘口气"的出口——要么是能说服兄弟姐妹分担的凭据/分工办法，要么是花父母的钱请到可靠替手而不被指责乱花钱的底气。
谁被现在市面上的产品排除了：多子女家庭里"被默认扛事"的那个子女——现有照护建议默认"全家人商量着来"，没人管"商量了也没人来"的情况；也排除了想花父母的钱请 respite 却怕兄弟姐妹说闲话的人。
生活域：心智（照护场景·照护者情绪与 burnout）
命中的机会镜头：细分人群与特殊情境（多子女家庭中独自扛事的那个——被"家人会分担"的默认假设排除）＋高价值问题（长期、耗竭、不可逆：16 年脱产）；三维交叉：时间（父母失能后的数年）×人群情境（多子女家庭的实际照护者）×支付动机（花小钱换喘息、换"我不是一个人在扛"的凭据）；买家≠使用者：子女买、父母间接受益；特殊情境：兄弟姐妹缺席
证据：强（4 个独立帖子跨 2 个社区＋YouTube 6 条高赞评论，跨 3 种信源类型互证；非付款买家）
货架核查：未做
补充记录（每日扫描 2026-10-24，日语区单出处·弱）：note.com《親の介護費用の分担を兄弟に言い出せず先延ばしにしている夜に》（2026-10-20，会员付费墙，仅见摘要）https://note.com/keirin_kaiwai/n/n7596a59e7433 ——日语区变体："分担"之前的"言い出せない"（开不了口谈钱）。摘要给的土办法是"先把亲的年金/存款/费用列成表、算出缺口，再带着'自己能出多少＋能干什么活'去谈，谈完写下来定复查日"。与本条"说了也没人来"不同面（这面是"还没说出口"），单出处暂不占新号，留作本条补充。

## S-019 ｜ 2026-10-23 ｜ 状态：POOL ｜ 来源：远征 2026-10-23
来源：Mumsnet 帖《House Clearance - so overwhelmed, where do I start?》（2025-07-07，74 条回复）https://www.mumsnet.com/talk/property/5369249-house-clearance-so-overwhelmed-where-do-i-start ＋ Gransnet 帖《Clearing my late dad's place》同类佐证 https://www.gransnet.com/forums/bereavement/1357638-Clearing-my-late-dads-place?pg=2
顾客原话：OP："We now have the absolutely mammoth task of clearing out the house. Where do we start??" / "Its honestly giving me sleepless nights and we have not even got started on it yet."（摊上清整栋房子的巨活，从哪下手？还没开始干，已经愁得睡不着觉了。）｜ 回帖 Mumstheword2022："The hardest bit was all the paperwork. They kept everything. We killed two shredders and, in the end, burnt much of it in the garden... The pressure came on the being worried we would destroy something important!"（最难的是那堆文件，什么都留着，碎纸机干废两台，最后很多是院子里烧掉的。最大的压力是怕不小心销毁了重要的东西！）｜ YouTube（《5 Valuable Lessons In Swedish Death Cleaning》评论区）@nonawolf7495（592 赞）："My Dad was a hoarder... the entire lower level of my parents house is filled with crap that's piled up to the ceiling. Mom is 87 and has dementia. And oh yeah, I live 1200 miles away."（我爸囤积成性，父母家下一层堆满顶到天花板的东西。我妈 87 岁还痴呆。我住在 1200 英里外。）｜ @lisaleidy344（328 赞）："When she passed, my sister and I spent 2 years clearing out the house. In the end, we never got to the garage or the basement, which was packed floor to ceiling."（我妈走后，我和我姐花了 2 年清房子，最后车库和地下室都没清到。）
什么时刻、什么麻烦：父亲去世、房子已售出，继承人要在交房前清空一整栋房子。几十年的东西不知从哪下手；最磨人的是文件堆——几十年的账单、保单、证书混在一起，怕一碎就碎掉了重要的，只能硬着头皮一份份看；请清屋公司又觉得贵，只能自己一间间干。
这件事到底帮他做什么：在限定时间（交房期限）内，把"清空一整栋房子"拆成可执行的顺序——先干哪间、文件堆怎么过一遍不踩雷、哪些东西值得走拍卖/慈善、哪些直接扔，让人敢动手、不返工。
谁被现在市面上的产品排除了：要在期限内自己动手清屋的普通人——现有整理内容默认"慢慢来、按心情断舍离"，没人管"下个月必须交房"的倒计时；也排除了怕毁掉重要文件、不敢下手的人。
生活域：家（照顾父母·丧亲后清屋）
命中的机会镜头：高价值问题（有硬期限、量大、怕出错）＋时间窗口（交房期限倒计时）；三维交叉：时间（亲人去世后数周至数月、交房期限前）×人群情境（继承人、独自或和兄弟姐妹一起清屋）×支付动机（花小钱换"敢动手、不返工、不毁掉重要东西"）；买家≠使用者：子女替已故父母处理
证据：强（Mumsnet 74 回复帖＋Gransnet 同类帖＋YouTube 6 条高赞评论，跨 3 个平台互证；非付款买家）
货架核查：未做
去重备注：与 S-014 同属"清父母房子"大主题，但底层任务不同——S-014 是"悲伤中对每件物品做不了留/扔决定（情绪冻结）"，本条是"巨活不知从哪下手（启动与排序）＋文件堆怕毁掉重要东西"，不合并。

## S-020 ｜ 2026-10-23 ｜ 状态：POOL ｜ 来源：远征 2026-10-23
来源：AgingCare 论坛帖《What do you use to stay organized?》（2025-03，14 个回答）https://www.agingcare.com/questions/what-do-you-use-to-stay-organized-492747.htm
顾客原话：Gettingreal："I used excel spreadsheet sheets to track monthly expenses... I also used a separate calendar sheet for each caregiver each month... I kept a general care log and each caregiver was expected to document what mom did that day... I hated having to do this as I worked a full time job and was also a primary caregiver so spare time was nonexistent, but I'm glad I did for accountability purposes."（我用 Excel 记每月开支，每个护工每月一张日历表，还记总照护日志。我恨透了这份差事——全职上班＋主要照护者，根本没有闲时间——但为了能交代清楚，咬牙做了。）｜ mom2mepil："I keep a binder with all receipts, notes from every doctor appointment, an continuously-updated Word document listing all of Mom's medications... I can just hand the binder to my sister or whomever needs it when I go on vacation."（我自己做了个 binder：所有收据、看病笔记、持续更新的用药 Word 文档。我要出门时直接递给我妹，她就能接手。）｜ KNance72："I am Not that computer savvy either. Post things On the refrigerator."（我也不太懂电脑，东西都贴冰箱上。）
什么时刻、什么麻烦：开始替失能父母管钱、管药、管看病之后，信息散在各处——哪个护工哪天来的、药什么时候调的、上次看病医生说了什么，全凭脑子记。全职上班＋照护双重负荷下，只能用 Excel＋手写本＋冰箱贴硬扛，还要防着兄弟姐妹问起钱时说不清。
这件事到底帮他做什么：把散在脑子、Excel、手写本、冰箱贴上的照护信息收进一个"交代得清、交得出班"的地方——钱和药随时说得清，自己出门时别人能接手。
谁被现在市面上的产品排除了：不太懂电脑的年长照护者（"东西都贴冰箱上"）——现有工具默认用户会用 app/电子表格；也排除了"怕说不清钱"的照护者，现有产品默认记账只是为了自己看。
生活域：家（照顾父母·日常照护记录）
命中的机会镜头：细分人群与特殊情境（不太懂电脑的年长照护者——被默认假设排除）＋高价值问题（钱和药说不清会出大事）；买家≠使用者：子女买、父母/护工/兄弟姐妹看；特殊情境：多子女家庭的 accountability
证据：中（同一帖 4 位照护者各自土办法＋Etsy caregiver binder 供给侧有人买；非付款买家）
货架核查：未做
关联：F4（照护者 Binder，案头）的需求侧回声。

## S-021 ｜ 2026-10-23 ｜ 状态：POOL ｜ 来源：远征 2026-10-23
来源：Amazon《The Complete Eldercare Planner》4th ed.（Joy Loverde，195 评价）买家评价 https://www.amazon.com/dp/B0CGPN5STZ（评价经 myus 镜像页亲读核验）
顾客原话：sarindfw："The book is helpful, but there is so much information, I will never have time to work all the way through it. For this to be useful and worth the cost, it needs to be marketed to a younger crowd and helping them understand what to do Long before they face Eldercare"（书有用，但信息太多，我永远没时间读完。它应该卖给更年轻的人，让他们在真正面对养老照护之前就知道该做什么。）｜ Amazon Customer："Ok, not great. A lot of very common sense. Not a lot of different information. Very good for basics."（还行，全是常识，没什么不一样的信息，打基础可以。）
什么时刻、什么麻烦：父母突然失能/住院/确诊，子女在危机中买书想立刻知道"先干哪几件"，结果拿到一本读不完的"教材"——要么太厚读不完，要么读完发现全是常识。
这件事到底帮他做什么：在父母失能前或危机刚起时，用最短时间抓住"现在必须先做的几件事"，而不是系统学习养老知识。
谁被现在市面上的产品排除了：没整块时间读书的在职照护者；已经在危机里、需要行动清单而不是教科书的人。
生活域：心智（照护场景·危机应对）
命中的机会镜头：高价值问题（危机时刻、紧迫、容错低）；三维交叉：时间（父母失能/确诊的危机窗口）×人群情境（在职子女、突然被推上照护者位置的人）×支付动机（花小钱换"先干哪三件"的确定性）
证据：硬（Amazon 已付款买家亲口说；镜像页不显示评价日期，24 个月窗口未验证，如实标注）
货架核查：未做

## S-022 ｜ 2026-10-23 ｜ 状态：POOL ｜ 来源：远征 2026-10-23
来源：Amazon《Sorry It's Your Problem Now Because I'm Dead》（Eternal Leaves Publishing，63 评价）买家评价 https://www.amazon.com/dp/3989910523（评价经 myus 镜像页亲读核验）＋ Amazon《Oops, I Died... But Don't Worry I Left You This!》买家 fran wiedenhoeft 跨产品佐证
顾客原话：Jane Starwood："My only complaint is that there is too much space in some sections and too little in others, but that's minor."（唯一的抱怨是有些章节留白太多、有些又太少。）｜ fran wiedenhoeft："Most people's lives are so full that they are going to have just a few more things they wanted to pass on."（大多数人的一生都很满，想留的话总比预留的多几句。）
什么时刻、什么麻烦：坐下来填身后事 planner——整理账户、联系人、遗愿时，发现有的格子写两行就空着，有的根本写不下。通用模板按"标准家庭"设计，情况复杂的人（多套房、多账户、再婚家庭）装不下。
这件事到底帮他做什么：把"我死后家人要知道的一切"一次性写全，家人一眼能找到，不用猜、不遗漏。
谁被现在市面上的产品排除了：情况复杂的人（多套房、多账户、重组家庭）——固定版式默认"标准家庭"；想留长留言的人。
生活域：家（身后事·信息交代）
命中的机会镜头：细分人群与特殊情境（情况复杂的家庭——被"标准家庭"默认假设排除）＋高价值问题（写不全＝家人日后抓瞎）；买家≠使用者：自己填、家人用
证据：硬（Amazon 已付款买家亲口说；跨产品佐证；镜像页不显示评价日期，如实标注）
货架核查：未做

## S-023 ｜ 2026-10-23 ｜ 状态：POOL ｜ 来源：远征 2026-10-23
来源：Google Play「Itemtopia Home Inventory」（com.itemtopia.app）1–2 星差评 6 条同类（2024-10 至 2026-10，评论经官方接口亲拉核验）
顾客原话：m compton（2025-11-02，1 星）："free version - only 5 items? I wanted to document a few of my parents things so I could remember who, what, where etc."（免费版只给 5 件？我只是想记录一下父母的几件东西，好记住哪件是谁的、在哪。）｜ K S Wood（2026-05-20，1 星）："20 items as an inventory app is a joke."（一个盘点 app 只给 20 件是开玩笑。）｜ Veronica Franco（2024-10-26，1 星）："Only 20 items for free version. You're better off creating a spreadsheet."（免费版只有 20 件，还不如自己做电子表格。）
什么时刻、什么麻烦：搬家前盘点、或想给父母的东西建个底（哪件是谁的、在哪、以后怎么分）时，打开物品清单 app，发现免费版只给 5–20 件——连"试试合不合用"都不够；花几天录了几百件后，被告知要交 $40/年才能继续用。
这件事到底帮他做什么：一次性把家里/父母的东西盘点记录下来（保险用、记住哪件是谁的、以后分的时候有凭据），不被年费绑架。
谁被现在市面上的产品排除了：只需要"做一次盘点"的人（搬家、保险、记录父母物品）——产品按年订阅收费，免费试用量小到不够试用；预算有限的普通用户。
生活域：家（物品盘点·父母物品记录）
命中的机会镜头：细分人群与特殊情境（只想做一次盘点的人——被"订阅制"默认假设排除）；三维交叉：时间（搬家前/父母搬迁时的一次性窗口）×人群情境（要记录父母物品的子女）×支付动机（花小钱一次买断"盘完就行"，不被年费绑架）
证据：硬（应用商店用户原话，6 条同类；24 个月内）
货架核查：未做
关联：m compton 的"记录父母的几件东西，记住哪件是谁的、在哪"与 S-013（分物）/S-014（清屋）直接相邻。相邻已付费：DJ Johnson 正在付 $40/年（有人为此付钱，但价格结构不对）。

## S-024 ｜ 2026-10-23 ｜ 状态：POOL ｜ 来源：远征 2026-10-23
来源：Google Play「Empathy - Loss Companion」（com.empathy.companion）1–2 星差评 3 条同类（2026-02/03，评论经官方接口亲拉核验）
顾客原话：Sophia Hicks（2026-03-08，1 星）："there is no way to proceed past this access wall unless I harbor a code from an insurance company... I don't have the spoons to remember... So much for being there in *my* time of need."（根本过不去这道墙，除非你有保险公司给的码。我实在没精力记。在我最需要的时候，它不在。）｜ Paul Jay（2026-03-18，1 星）："I never got to the grief part I was so pissed at having to go through hoops to get there. pointless app I deleted it."（我压根没走到哀伤支持那部分，光为进门折腾就气够呛。没意义，删了。）
什么时刻、什么麻烦：亲人刚去世、要处理注销账户/遗产杂事＋情绪崩溃时，下载丧亲支持 app 想求助，第一步就被"保险公司邀请码"墙挡住——最需要帮助、精力最差的人，连门都进不去。
这件事到底帮他做什么：在刚失去亲人、独自一人、精力耗尽时，找到能帮自己处理身后杂事和情绪的人/工具，不用先过一道身份墙。
谁被现在市面上的产品排除了：没有保险公司渠道的人；精力耗尽的丧亲者；独生子女独自扛事的人（同 app 评论区 Andrea Svensson："lost my dad... my son... I'm an only child... been doing this alone"）。
生活域：心智（丧亲场景·哀伤支持）
命中的机会镜头：细分人群与特殊情境（无保险渠道的普通人、独生子女——被"B2B2C 获客"默认假设排除）＋高价值问题（至暗时刻求助无门）
证据：中（3 条同类差评，2026 年内；非付款买家）
货架核查：未做
注：相邻已付费行为弱（该 app 是保险公司合作模式，个人付费证据不足），如实标注。

## S-025 ｜ 2026-10-23 ｜ 状态：POOL ｜ 来源：远征 2026-10-23
来源：Google Play「Caring Village」（com.caringvillage.app）1–2 星差评 2 条同类（2026-01、2025-04）
顾客原话：Shandice Johnson（2026-01-13，2 星）："It doesnt allow skipping a dose. My mom got confused how to view her next dose. The care plan is so rigid... Asking $25/ month for a bigger village is ridiculous, seeing as $15 is already way overpriced"（不允许跳过一次。我妈看不懂下一次该吃哪顿。照护计划死板得要命。家庭圈只让加 5 个人，加人要 $25/月，离谱——$15 本来就贵得离谱。）｜ sarah barkley（2025-04-10，2 星）："it routinely gets confused about what the day is and therfore makes it difficult to accurately track things for your loved ones."（它老是搞不清今天是几号，很难准确记录亲人的情况。）
什么时刻、什么麻烦：每天给父母管药、做一天多次的理疗时，app 的吃药计划刻板到不能跳过一次、日历还差一天；被照护的老人自己看不懂下一次该吃哪顿；超过 5 个人的大家庭要加钱。
这件事到底帮他做什么：一家人在同一份记录上，把老人的吃药和日常照护管对——老人自己也能看懂。
谁被现在市面上的产品排除了：被照护的老人自己（"我妈看不懂"）——现有 app 默认是子女在用；超过 5 个人的大家庭；预算有限的家庭。
生活域：家（照顾父母·用药与照护记录）
命中的机会镜头：细分人群与特殊情境（被照护老人自己、大家庭——被默认假设排除）；买家≠使用者：子女买、老人用
证据：中（2 条同类差评，24 个月内；非付款买家）
货架核查：未做

## S-026 ｜ 2026-10-23 ｜ 状态：POOL ｜ 来源：远征 2026-10-23
来源：Amazon《Self-Care for Caregivers》（Susan M. White，68 评价）买家 JArmadillo 评价 https://www.amazon.com/dp/1507218397
顾客原话：JArmadillo："Nothing special here, just common sense that I already knew. Not sure what I was looking for in this book, but I didn't find it. There are no great solutions for this challenging situation."（没什么特别的，全是我早就知道的常识。我也不确定想找什么，但没找到。这么艰难的处境，没有真正管用的解法。）
什么时刻、什么麻烦：长期照护者情绪耗竭、想找自救办法时，买书发现讲的都是"要爱自己"这类早就知道的道理——连退货的精力都没有（同书 Michelle："likely can't be bothered to return but this will annoy me"）。
这件事到底帮他做什么：在每天被照护任务吞没、没时间没精力时，找到能真正减轻负担的具体办法，而不只是心理按摩。
谁被现在市面上的产品排除了：重度照护负担者（24 小时连轴转、无喘息时间的人）——这类书默认读者有整块时间读书实践"自爱"。
生活域：心智（照护场景·照护者情绪）
命中的机会镜头：细分人群与特殊情境（重度负担、无喘息时间的照护者）；高价值问题（耗竭、抑郁风险）
证据：硬（Amazon 已付款买家亲口说；单源弱项，如实标注；镜像页不显示评价日期）
货架核查：未做

## S-027 ｜ 2026-10-23 ｜ 状态：POOL ｜ 来源：远征 2026-10-23
来源：Amazon《Oops, I Died... But Don't Worry I Left You This!》（35 评价）买家 fran wiedenhoeft 评价 https://www.amazon.com/dp/B0F7GBR9F2
顾客原话：fran wiedenhoeft："The only thing I felt should not have been left out was a section for veterans. There are so many particulars to a veteran's passing regarding life insurance, survivor benefits plans, VA surviving spouse plans, veterans benefits for disabled veteran's children to go to college, and whether to have and where to find an honor guard at the funeral."（唯一不该漏掉的是退伍军人专区。退伍军人身后事太多特殊事项：人寿保险、遗属福利、VA 遗孀计划、残障退伍军人子女上大学的福利、要不要仪仗队、去哪找。）
什么时刻、什么麻烦：退伍军人家庭准备身后事时，拿着通用模板逐项填，发现"军人"相关那一整块根本没地方写——VA 福利、仪葬流程全漏。
这件事到底帮他做什么：确保特定身份（退伍军人）的身后福利、仪式事项一个不漏地交代给家人。
谁被现在市面上的产品排除了：退伍军人及其遗属——通用模板默认"平民"，一整套 VA 福利/仪葬流程被整体漏掉。
生活域：家（身后事·特定身份）
命中的机会镜头：细分人群与特殊情境（退伍军人家庭——被"平民默认"假设排除）
证据：硬（Amazon 已付款买家亲口说；单源弱项，如实标注；镜像页不显示评价日期）
货架核查：未做

## S-028 ｜ 2026-10-23 ｜ 状态：POOL ｜ 来源：远征 2026-10-23
来源：Amazon《Planner Perfect: A Fresh Idea On Organizing Your Life》（Jenny Penton，193 评价）买家评价 https://www.amazon.com/dp/B0084I8RDM
顾客原话：Viride："This approach is a bit more cumbersome than most but does have results... Note: the website is ok but also a little hard to follow in places."（这套方法比别家更繁琐，但确实有效果。她网站有些地方也不好跟。）｜ Carol Butterworth："it doesn't currently reflect the website and social media as the method has moved forward."（书的内容已经跟不上网站和社媒上迭代后的方法了。）｜ NKYhomeschooler（4 星）："I'm giving this 4 stars instead of 5 due to a lack of editing."（因为编辑问题只给 4 星。）
什么时刻、什么麻烦：跟着书搭建家庭 binder 时，发现步骤比别家繁琐、跟作者网站对不上——买到的已是旧版方法，还要自己到处找更新。
这件事到底帮他做什么：用一套不折腾、跟得上更新的方法，把全家事务收进一个 binder。
谁被现在市面上的产品排除了：没时间折腾复杂系统的人（"cumbersome"的方法默认用户有大把时间）；买了书才发现方法已更新、白学旧版的人。
生活域：家（家庭管理· binder 方法）
命中的机会镜头：大众常青（家庭管理是长期需求）；三维交叉：时间（决定整理家庭事务时）×人群情境（没时间折腾的人）×支付动机（花小钱换"不折腾、跟得上"）
证据：硬（3 条独立评价，已付款买家；镜像页不显示评价日期，如实标注）
货架核查：未做

## S-029 ｜ 2026-10-23 ｜ 状态：POOL ｜ 来源：远征 2026-10-23
来源：Google Play「MoveAdvisor Moving Planner」（com.moveadvisor.bundle）1–2 星差评 9 条同类（跨 2016–2025，2 条在近 24 个月内）
顾客原话：Rebekah Loper（2025-10-12，1 星）："Just downloaded and immediately uninstalling cause I can't even use it without giving contact info."（刚下载就卸载，不给联系方式连用都用不了。）｜ A Google user（2022-01-19，1 星）："I hit the button that said get a free quote...huge mistake! They've now given my phone number and email to what seems like every moving company in the state and they won't stop calling!"（点了"免费报价"大错特错！他们把我的电话给了州里几乎每家搬家公司，电话停不下来！）｜ Alyssa Maldonado（2022-06-24，1 星）："I added my info thinking it would be a useful app to help me move myself and immediately got tons of calls after I put a quote in."（我以为是个帮我自己搬家的工具，结果一提交电话就爆了。）
什么时刻、什么麻烦：下载搬家规划 app，想自己规划一次搬家（清单＋盘点），第一屏就被姓名＋邮箱＋电话表单挡住；点"免费报价"后几天内被搬家公司电话短信轰炸。想 DIY 搬家的人发现这 app 实质是搬家公司的获客漏斗。
这件事到底帮他做什么：自己规划一次搬家（清单＋盘点），不想被推销、不想交个人信息。
谁被现在市面上的产品排除了：想自己动手搬家（DIY）的人；跨境/跨国搬家者（"It doesn't work if you're moving abroad"）。
生活域：家（搬家·自主规划）
命中的机会镜头：细分人群与特殊情境（DIY 搬家者——被"找搬家公司"的默认假设排除）；三维交叉：时间（决定搬家后）×人群情境（自己动手搬家的人）×支付动机（花小钱换"不被推销、不用交隐私"的清净）
证据：中（9 条同类差评，2 条在近 24 个月内；应用商店用户）
货架核查：未做
去重备注：与 S-012（搬家 72 小时）不同面——S-012 是"搬家当天/头 72 小时秩序恢复"，本条是"搬家规划工具被获客漏斗污染"，不合并。

---

## S-030 ｜ 2026-10-24 ｜ 状态：POOL ｜ 急
来源：① note.com ぷち（主婦歴17年）《私、年末に大掃除しません。9月から始める「ちょこちょこ大掃除」》（2026-09）https://note.com/puchi_2026a/n/n0d22b00d5498 ＋ ② note.com Chie Ishikawa《去年より早く取りかかれていると発見した話》（2026-10-17）https://note.com/loverchiek/n/nddca6fa2b47e ＋ ③ Lemon8 りんご「簡単掃除と暮らし」大掃除チェックリスト投稿（2026年）https://www.lemon8-app.com/kaori.y.t/7180871093899821574?region=jp ＋ ④ note.com Azu《年末大掃除が「毎年挫折する」本当の理由》（2025-12）https://note.com/s_s335/n/n25f7ee79500d ＋ 佐证：グラフィコ「夫婦の家事意識調査」（2022年调查，老材料仅作佐证）https://home.kingsoft.jp/news/gourmet/tokubai/6095.html ＋ 家事代行ミニメイド「10月からの逆算スケジュール」（2026-10-20）https://www.minimaid.co.jp/blog/index170/
顾客原话：ぷち：「あと○日しかないのに、ここもやってない！」となるのが嫌なんです。｜「掃除した場所と日付を書いて、「去年ここ、いつやったっけ？」が分かるようにしています。」（自作の記録表を9月から運用）｜ Chie：「今年も掃除が思ったほど進んでない」「一昨年の反省を生かして、年間掃除計画を立ててます。」（去年12月の計画と今年の進捗を照合）｜ りんご：「リクエストをいただいていた『お掃除チェックリスト』出来ました」（フォロワーからのリクエストに応えて作成、786いいね・244保存）｜ Azu：「今年こそ、ちゃんと大掃除しよう」そう思いながら、気づけば12月30日。慌てて換気扇だけ拭いて「まあ、いいか」で終わる——。｜ ダスキン調査（Azu引用）：2024年末の大掃除実施率は51.1%で過去最低、約5人に1人が「やろうと思っていたのに、できなかった」。｜ グラフィコ調査（佐证）：妻の不満「夫が大掃除に参加しない」「中途半端な参加」；「夫婦間で目指す大掃除のゴールのギャップに悩む声や、喧嘩にまで発展してしまったという声も。」
什么时刻、什么麻烦：10月下旬到12月，日本家庭一年一度的年末大掃除。想做的人年年"今年こそ"，结果12月30日才慌，换气扇擦完就收工；想认真做的人发现全家只有自己在动，一开口分配任务就因"目标不一致"吵起来。有人9月就开始自己画表，记下"哪天扫了哪、去年这时候做到哪"。
这件事到底帮他做什么：在12月31日这个硬截止前，把"一年没碰的地方"拆成小块、排进已经很满的日程（共働き家庭周末没空），并且一眼看出"去年做到哪、今年还剩多少"，让不参与的家人也能认领——而不是12月最后一周靠一个人硬扛。
谁被现在市面上的产品排除了：12月才想起来的人（现有清单默认你12月有整块时间）；共働き家庭（周末被工作/孩子的事占满，只能用15分钟碎片）；想让家人参与、但"一分配就吵架"的家庭（现有清单默认一个人干完）。
生活域：家（年末大掃除·计划与分担）
所属语区：日语区
命中的机会镜头：时间窗口（年末硬截止；现在10月下旬正是计划窗口，ミニメイド亦称10月下旬〜11月上旬启动）＋细分人群与特殊情境（共働き家庭、一分配就吵架的家庭——被"一个人干完"默认假设排除）；三维交叉：时间（10–12月倒计时）×人群情境（共働き／家人不参与）×支付动机（花小钱换"不用12月30日一个人崩溃"）
证据：中（3个独立近期出处互证：10月note个人计划记录、9月note自制进度表、Lemon8读者点单＋收藏；非付款买家）
互证出处清单：[1] note ぷち（自制记录表，2026-09）[2] note Chie（年度计划对照，2026-10-17）[3] Lemon8 りんご（读者要求 checklist，786赞/244收藏）[4] note Azu＋ダスキン数据（2025-12，佐证"每年挫折"面）[5] グラフィコ2022调查（老材料，仅佐证"分担吵架"面）
货架核查：Etsy 有英文 routine cleaning checklist 在售（SimplySortedJB bundle AU$8.36、HakiNet $2.45、Deelix $3.99；均为日常/周/月维度，非年末大掃除专用，无日语版）；Etsy JP 有キッチン掃除チェックリスト（6.40 CAD，厨房专用）；creema／minne 搜索未见大掃除チェックリスト在售（仅见博客免费PDF：moomii.jp、kosouji.com，及 Lemon8 免费下载）。结论：日语"年末大掃除"专用计划表未发现同类在售。
急爆发依据：大掃除计划窗口正在打开——家事代行ミニメイド（4天前）称10月下旬〜11月上旬为启动点；StartHome 今日（2026-10-24）转载"師走が近づき、大掃除を意識し始める季節"；两位 note 主妇9–10月已开始自制进度表。再晚上浮就过期（12月执行、1月失效），故标急先行上浮。

## S-031 ｜ 2026-10-24 ｜ 状态：POOL
来源：① note.com たく@2児のパパ《家事を「見える化」したら、自分がやっていたのは全体の2割だった話》（2026-10-11）https://note.com/taku_ikuji04/n/n2f39557c64a5 ＋ ② ESSE「女性の"お悩み"研究所」夫婦の家事シェア調査（2026-09-30，读者252人）https://prtimes.jp/main/html/rd/p/000001772.000026633.html
顾客原话：たくの妻：「気づいて動くこと自体が、もう一つの仕事なんだよ」｜「気づいたことを毎回言葉にして頼むのも、地味に疲れる」｜ たく：夫婦で家事を書き出したら62個のタスク、夫13個・妻41個——「自分では5割くらいはやっているつもりでいたのに、数えてみると全体の2割程度しか担当していなかった」｜ ESSE 调查：30代〜60代夫婦の家事分担は「9：1」の割合が最多（在职妻子约7成）｜ 读者コラーゲンさん（40代·兼职）："99%私が家事をしています。お願いすればやってくれますが、夫からなにかをするとかはありません"（99%家务是我做。求他会做，但他从不主动。）｜ 读者あやさきさん（30代）："『オムツが減っていたよ』と言うだけ。記名してよ！"（他只说"尿布快没了"，倒是写上名字啊！）
什么时刻、什么麻烦：每天的家务。丈夫觉得自己"分担了一半"（倒垃圾、洗碗、洗浴室），妻子却在管所有"看不见的活"：发现洗剂快用完了、记得给尿布写名字、提前准备好打预防针的文件。妻子把"发现问题并开口求人"本身也当成一份工，丈夫却觉得"你说了我就干"。两边对"谁干了多少"的体感差出一倍以上，谈一次分工就成吵架或冷战。
这件事到底帮他做什么：把家里全部的活（含"发现、记住、开口"这些看不见的活）一次性摊开数清楚，让两个人对"谁在干多少"有一本相同的账——谈分工时谈的是同一张表，而不是各自的体感。
谁被现在市面上的产品排除了："说了我就干"型丈夫（现有分工表默认任务是看得见的洗碗扫地，不含"发现与记住"）；在职妻子（ESSE：在职约7成，分担仍是9:1——现有内容默认妻子管家）。
生活域：家（日常家务分担·名もなき家事）
所属语区：日语区
命中的机会镜头：细分人群与特殊情境（在职妻子家庭、"说了就干"型丈夫——被"妻子管家／任务都看得见"默认假设排除）＋大众常青（每天发生）；三维交叉：时间（每天）×人群情境（在职妻子＋被动型丈夫）×支付动机（花小钱换"吵架时有同一张表可谈"）
证据：中（2个独立近期出处互证：10月父亲的个人实验记录、9月杂志读者调查252人；非付款买家）
互证出处清单：[1] note たく（62项任务可视化实验，2026-10）[2] ESSE 调查（n=252，多条读者原话，2026-09-30）
货架核查：Etsy 有英文同类在售——Couples Chore Chart 市场约150个结果（$4.51–$25.69）、Mental Load Workbook Couples 44页 $9.40（ALittleMoreRoom）、Family Chore Chart $1.60–$2.98；均为英文，日语版未见；creema／minne 未见在售。
去重备注：与 S-016（钱·伴侣分账）相邻但底层任务不同——那条是"账本之外的小钱现形"，这条是"看不见的家务劳动现形"，一个是钱、一个是活，不合并。与 S-030 同属"分担"大主题但时刻不同——S-030 是年末一次性事件的倒计时＋分担，本条是日常每天的体感差，不合并。

---

## S-032 ｜ 2026-10-24 ｜ 状态：POOL ｜ 来源：远征 2026-10-24
来源：① Etsy Christmas Planner 市场 spotlight（快照约 2026-07 前）已付款买家 doro bieber 5★ 评价 https://www.etsy.com/ca/market/christmas_planner（镜像页不显示评价日期，如实标注） ＋ ② Mumsnet《What's your Christmas budget?》（2025-11-09，194 回复）https://www.mumsnet.com/talk/_chat/5441082-whats-your-christmas-budget?page=6 ＋ ③ YouTube @tricianottingham1785（2025-10-24）https://www.youtube.com/watch?v=iPRU3-Zn-OA ＋ ④ YouTube @kimpaugh4495（2019-10-24，窗口外仅佐证持续性）https://www.youtube.com/watch?v=nkHPpspLOtk
顾客原话：doro bieber："It has helped me so much to budget my christmas presents. Because they can sneak up on you and really add up…"（圣诞礼物这笔钱总在不知不觉中越花越多，买完一算吓一跳。）｜ Mumsnet 回帖："what we could get for a lot less a few years ago has crept up alarmingly"（几年前便宜很多的东西，现在贵得吓人，不知不觉就超了。）｜ @tricianottingham1785："What happens if I hit a birthday and the gift is more than I have saved?"（存的钱不够买礼物、超了预算怎么办？）｜ @kimpaugh4495："I am only spending about $500 this year. I am on a tight budget and I really don't want to go crazy and stress myself out."（今年只花 500 美元，手头紧，不想把自己逼疯。）
什么时刻、什么麻烦：11–12 月买礼物时，一件件单看都不贵，加起来远超心理预期；物价上涨让往年的预算基准失效。等意识到超支时，钱已经花出去了。
这件事到底帮他做什么：在"不知不觉"发生之前，就看到"已经花了多少、还剩多少"，超支苗头一冒就掐住。
谁被现在市面上的产品排除了：对价格敏感但记账坚持不下来的人——现有预算表默认用户会"自觉逐笔记录"；只想设个总数、不想管明细的人。
生活域：节庆（圣诞）×钱（礼物预算失控）｜所属语区：英语区
命中的机会镜头：时间窗口（圣诞季集中爆发）＋大众常青（预算失控是常年麻烦，圣诞季被放大）
证据：中（跨三类信源互证：电商已付款买家×社区×视频评论；24 个月内直接原话分散，普遍性证据不足，如实降级）
互证出处清单：[1] Etsy 已付款买家评价（doro bieber）[2] Mumsnet 2025-11 帖（194 回复）[3] YouTube 2025-10 评论 [4] YouTube 2019 评论（窗口外，仅佐证"sneak up"是持续性麻烦）
货架核查：Etsy 圣诞预算类在售密集——StillRootsStudioCo Christmas Budget Tracker Google Sheets $9.99（10 个页签，含礼物预算＋储蓄计划）；SavvyandThriving Christmas Gift Tracker $3.67（5 折后）；LawsonMadeCo Christmas Budget Planner Google Sheets（带视频教程）；PlanneryLab Goodnotes 圣诞 planner $5.99。价格带 $3.67–$9.99，评价量级 5–119。结论：供给密集，"防超支"是各家都在讲的卖点。
用途标注（2026-10-25，Lee 已定）：供 S-006／Kit pin 文案角度。

## S-033 ｜ 2026-10-24 ｜ 状态：POOL ｜ 来源：远征 2026-10-24
来源：① Mumsnet《My Christmas expenses look to be totalling over £1000》（2025-11-22，475 回复；协调员已独立打开核验：帖子/回复数/日期/原话逐字吻合）https://www.mumsnet.com/talk/am_i_being_unreasonable/5448197-my-christmas-expenses-look-to-be-totalling-over-ps1000 ＋ ② Reddit r/AmItheAsshole（经 postize 转载，2025-12-07；转载非原生 URL，如实标注）https://postize.com/aita-overspending-christmas-gifts-despite-2a ＋ ③ MSE 论坛 https://forums.moneysavingexpert.com/discussion/6320051/whats-the-biggest-christmas-waste-of-money/p3 ＋ ④ 调查数据佐证（远征 05 线摘录：英国央行 12 月多花 29%、ASIC 44% 后悔过圣诞花销；主代理未独立核验，仅作佐证）
顾客原话：Mumsnet 发帖人："I would be using savings which I am saving for something important... and I would have to cut back a lot in January"（得动用存着办大事的钱，1 月全家勒紧裤腰带。）｜ 回帖："is being skint in January worth it (for many, many people it very much would be)"（1 月穷得叮当响，值吗——对很多人来说，值。）｜ Reddit 发帖人："I couldn't resist the temptation to go overboard with presents"…"I feel guilty for adding to their stress"（没忍住把礼物买过头了，给伴侣添了压力，很愧疚。）｜ MSE 回帖："Buying things on credit cards and paying back over the following year is probably one of the worse practices."（刷信用卡、来年慢慢还，大概是最糟的做法之一。）
什么时刻、什么麻烦：圣诞当下"不能亏待家人"的心态压过预算，12 月刷卡/动储蓄一时爽，1 月账单到才发现：重要储蓄被挪用、信用卡要跨年还、1 月生活质量骤降。后悔，但每年重复。
这件事到底帮他做什么：在 12 月动手花之前，就把"1 月的自己"摆上台面——让未来的账单在当下可见，或者 1 月有套现成的收拾残局办法。
谁被现在市面上的产品排除了：圣诞季"先花了再说"的人——现有预算表默认用户是"事前规划型"，对"事后收拾型"没有着落；1 月已经紧缩、需要"重置"的人。
生活域：节庆（圣诞）×钱（节后后遗症）｜所属语区：英语区
命中的机会镜头：时间窗口（1 月后遗症；预防性购买的窗口在 10–11 月）＋高价值问题（动用重要储蓄、信用卡跨年利息，是真金白银的代价）
证据：硬（跨社区强互证：Mumsnet 475 回复大帖＋Reddit＋MSE；降级点：Reddit 为转载非原生）
互证出处清单：[1] Mumsnet 2025-11 大帖（475 回复）[2] Reddit r/AmItheAsshole（2025-12，转截至 postize）[3] MSE 论坛同主题帖 [4] 英国央行/ASIC 调查数据（佐证"普遍性"面）
货架核查：Etsy 上"1 月冲击"已是卖家在用的购买钩子——UKLifeSorted Christmas Budget Planner UK 标题直写 "No January Shock"（£ 计价，Excel＋Sheets）；LawsonMadeCo 文案写 "pay for Christmas without the January credit card hangover"；AltairGoldShop Ber Months Planner 内含 "January recovery plan + no-spend January tracker"。结论：1 月后遗症麻烦已被商品化承接，卖家把它当卖点讲；专项"1 月重置"独立产品少见，多为圣诞 planner 里的一个页签。

## S-034 ｜ 2026-10-24 ｜ 状态：POOL ｜ 急 ｜ 来源：远征 2026-10-24
来源：① Mumsnet gift spreadsheet 帖（2012-10-19，老材料仅佐证"13 年未被解决"的持续性）https://www.mumsnet.com/talk/christmas/1591326-Anyone-else-have-a-Christmas-gift-spreadsheet ＋ ② Mumsnet《Budgeting - how!》（2024-07-23，84 回复；主代理已独立打开核验，原话逐字吻合）https://www.mumsnet.com/talk/christmas/5126151-budgeting-how ＋ ③ Mumsnet《Apps and organisation》（2025-12-28；主代理已独立打开核验，原话逐字吻合）https://www.mumsnet.com/talk/christmas/5466362-apps-and-organisation ＋ ④ YouTube @manondeusjen8433（2024-10-24）https://www.youtube.com/watch?v=iPRU3-Zn-OA ＋ ⑤ App Store「The Christmas List」rachelrn8 1★（2025-11-15）＋ arFan3609 2★（2024-11-23，付费用户）＋ Christmas Gift List Tracker 用户 2★（2024-12-13，付过费）＋「Santa's Bag」ljensen721 1★（2025-10-28）——经 Apple 评价接口读取 ＋ ⑥ Etsy 已付款买家 Ashli Martinez 5★（单买家弱项，如实标注）https://www.etsy.com/nz/market/printable_christmas_checklist ＋ ⑦ r/Frugal（经 Bored Panda 采访转载）https://www.boredpanda.com/easiest-frugal-change/?media_id=7468294
顾客原话：2012 年 Mumsnet："ended up giving my DSis a duplicate of something I'd given her 2 years ago just a different colour"（表格没更新，送了和两年前一模一样的礼物，只是颜色不同，尴尬。）｜ Kneenightmare（2024-07）："I track all the presents I buy on an excel spreadsheet to stop myself going too mad and try to stick to a budget for each person."（我用 Excel 记每件礼物，免得自己买疯，每人按预算来。）｜ Snozzlemaid（2025-12）荐 Santa's Bag："You can set an overall budget and add individual budgets for everyone you buy for…mark presents as an idea, purchased, wrapped and given"（能设总预算＋每人预算，礼物标"想法/已买/已包/已送"状态。）｜ @manondeusjen8433："When you do use the money in july to buy a christmas gift thats on sale from you sinking funds, how do you colour in your tracker since the amount won't be the fulltime amount you set your goal?"（7 月打折提前买了圣诞礼物，涂色追踪表对不上数了，怎么办？）｜ rachelrn8（App Store 1★）："I had all of my gifts loaded in for 2025 now they're all gone…there's no way to send for support. This is ridiculous. I paid for this."（2025 的礼物全录进去了，现在全没了，还联系不上客服，离谱，我可是付过钱的。）｜ ljensen721（1★）："when I opened the app everything was gone. Recipients, gifts… all the data is missing."（打开 app 全没了，收礼人、礼物都没了。）｜ arFan3609（2★，付费用户）："Purchased because... listed it's a collaboration... Manually sending updates via airdrop or email is not truly a shared collaborative list... I guess I'm gonna go back to using iPhone shared notes."（冲着"可协作"买的，结果还得手动 AirDrop/邮件同步，这算哪门子共享，只好回去用 iPhone 共享备忘录。）｜ Christmas Gift List Tracker 用户（2★，付过费）："I've tried to send it to my husband many times, it gives me the same error message... I ended up writing down on a notepad"（想发给我老公共享，次次报错，最后只好拿纸笔写。）
什么时刻、什么麻烦：从 10 月提前买打折货开始，到 12 月收尾，礼物清单散在各处：谁买了、买给谁、花了多少、藏在哪、包了没——Excel 要自己维护、app 丢数据（7 起丢数据投诉 2019–2026）、"协作"名不副实（还得手动同步）、提前买的折扣价和追踪表对不上。同一社区 2012→2024→2025 三代帖，13 年没被解决。
这件事到底帮他做什么：一份"买的过程中"就能对上数的清单——提前买的折扣、每人预算、购买/包裹/藏匿状态，在一个地方实时对得上，换手机/换 app 不丢。
谁被现在市面上的产品排除了：提前买打折的人（追踪表默认"12 月按原价买"，折扣价对不上）；想和伴侣真正共享的人（app 的"协作"多是手动同步的假协作）；app 丢过数据、不再信任 app 的人。
生活域：节庆（圣诞）×家（礼物清单追踪）｜所属语区：英语区
命中的机会镜头：高价值问题（重买的钱、送重样的尴尬、清单丢失的时间成本，都是硬代价）＋时间窗口（10 月提前买季正在发生，购买窗 11/20–12/20 内追踪需求即时爆发）
证据：硬（跨 4 信源类型强互证：社区×视频评论×应用商店×电商评价；降级点：Ashli Martinez 单买家弱；app 差评为匿名 ID，系商店常态）
互证出处清单：[1] Mumsnet 2012 帖（佐证持续性）[2] Mumsnet 2024-07 帖（84 回复）[3] Mumsnet 2025-12 求 app 帖 [4] YouTube 2024-10 评论（提前买场景）[5] App Store 4 条差评（3 个 app，2024-10—2025-11，含 2 名付费用户）[6] r/Frugal 采访 [7] Etsy 买家评价（弱项）
货架核查：Etsy gift tracker 在售密集——SavvyandThriving Christmas Gift Tracker $3.67（5 折后）；StillRootsStudioCo Christmas Budget Tracker $9.99（含 Gift Planner 页签：每人预算＋bought/wrapped 勾选）；PlanneryLab Goodnotes 圣诞 planner $5.99（5.0/5）；SelbyNash 2026 圣诞 planner $4.49；2026-10-12 新上架一款 $6.95（新进入者仍在进场）。价格带 $3.67–$9.99，评价量级 5–119。结论：供给密集，但买家侧"丢数据/假协作/折扣对不上"三类痛点在现有供给的评价区未见回应。
急爆发依据：10 月提前买打折正在发生（@manondeusjen8433 问的正是提前买场景）；圣诞购买窗 11/20–12/20 内追踪需求即时爆发，现在不记、12 月这批痛点就过去了。

## S-035 ｜ 2026-10-24 ｜ 状态：POOL ｜ 来源：远征 2026-10-24
来源：① Mumsnet《Secret Santa 最低消费扯皮帖》（2023-12-05，343 回复）https://www.mumsnet.com/talk/am_i_being_unreasonable/4957003-to-think-this-is-a-strange-way-to-do-secret-santa ＋ ② Mumsnet《Secret Santa 翻车帖》（2025-12-19，347 回复）https://www.mumsnet.com/talk/am_i_being_unreasonable/5462202-a-secret-santa-one-peed-off?page=14 ＋ ③ MSE 论坛 https://forums.moneysavingexpert.com/discussion/6320051/whats-the-biggest-christmas-waste-of-money/p3
顾客原话：2023 年帖："set a minimum price of £40…you have to spend over £40 on a single gift"（规定最低 £40，还必须"参加"）｜ 回帖："£40?! Ridiculous at any time, but especially with cost of living crisis!!!!!"（£40？平时就离谱，生活成本危机下更离谱！）｜ 2025 年帖："It basically looked like a raffle and nowhere near £20 worth, a tenner at best"（所谓 £20 的礼物看着像抽奖凑的，顶多值 £10）｜ "you know you are basically giving money away to join in and may get something you don't even want or like"（说白了就是花钱买个参与感，还可能收到根本不想要的东西；有同事收到"用黑胶带裹的 4 节 5 号电池"。）｜ MSE："plastic novelty gifts- especially for secret Santa's. It's just crap and ends up in the bin before the seasons even over"（塑料玩笑礼物，尤其 Secret Santa 的，纯属垃圾，季末前就进垃圾桶了。）｜ "anything that feels like an obligation is a waste of money"（只要是"不得不"花的钱，就是浪费。）
什么时刻、什么麻烦：办公室/大家庭搞 Secret Santa，规则（最低消费、必须参加）和礼物质量年年扯皮：定 £40 被嫌贵、收到货不对版的"十镑 raffle 货"、被迫参加还要假装开心。组织者两头受气。
这件事到底帮他做什么：让规则在开始前就立得明明白白（预算、是否强制、翻车礼物怎么算），或者让"不想参加"有个不伤和气的出口。
谁被现在市面上的产品排除了：被迫参加的人——现有 Secret Santa kit 默认"大家都乐意玩"，只解决抽签和问卷，不解决"规则扯皮"和"被迫社交"。
生活域：节庆（圣诞）×社交（礼物交换组织）｜所属语区：英语区
命中的机会镜头：细分人群与特殊情境（被迫参加的办公室/大家庭成员——被"自愿参加"默认假设排除）
证据：中（跨社区互证：Mumsnet 两帖 690 回复＋MSE；"麻烦真实存在"成立；但相邻已付费行为弱——未发现有人为解决"规则扯皮"付过钱，如实标注缺口）
互证出处清单：[1] Mumsnet 2023-12 帖（343 回复）[2] Mumsnet 2025-12 帖（347 回复，精准复现）[3] MSE 论坛
货架核查：Etsy Secret Santa kit 在售密集——ClovePixelStudio $4.46（9 页，问卷＋抽签＋规则）；PrettyPlansByKrystal $2.24（4.5★）；ThePresentTheory $8.00（5.0/3，含组织者指南）；ProperTemplatesUK £3.16（英国版，24 小时 16 次浏览）。价格带 $2.24–$8.00，评价量级多为个位数。结论：在售 kit 全是"组织工具"（抽签/问卷/标签），无一回应"规则扯皮/被迫参加"面。

## S-036 ｜ 2026-10-24 ｜ 状态：POOL ｜ 来源：远征 2026-10-24
来源：① MSE 论坛 savings diary（2026-01）https://forums.moneysavingexpert.com/discussion/6492874/save-more-spend-less/p27 ＋ ② MSE 论坛（2023-11）https://forums.moneysavingexpert.com/discussion/6484545/back-here-with-more-debt-than-ever-before/p7 ＋ ③ Mumsnet 2025-11-22 回帖（独立银行账户存圣诞钱） ＋ ④ mummakingmoney.com（2025-10）https://mummakingmoney.com/2025/10/28/christmas-debt-uk-how-to-avoid/ ＋ ⑤ YouTube sinking fund 评论区（@amymuy6677，2021-10-24，窗口外仅佐证"整套亚文化"存在）https://www.youtube.com/watch?v=pfOml3vfu5I
顾客原话：MSE（2026-01）："sent money over to Mr T's Christmas saving scheme and started my 52 weeks saving challenge"（把钱打进 Tesco 圣诞存钱计划，同时开了 52 周储蓄挑战。）｜ MSE（2023-11）："Christmas - £250 … All Christmas presents are done."（圣诞预算 £250，礼物全买齐了。）｜ Mumsnet 回帖："I save into a separate bank account to cover all my Xmas expenses."（单开一个银行账户存圣诞钱，专款专用。）｜ mummakingmoney："£50/month from January = £600 by December. That's a decent Christmas budget without using credit."（1 月起每月存 £50，到 12 月就是 £600，不用刷信用卡也能过个体面圣诞。）｜ @amymuy6677："This is the first year we were able to save for Christmas! ... without stressing about how I was going to pay for everything."（今年第一次攒够了圣诞钱，不用再为"钱从哪来"焦虑了。）
什么时刻、什么麻烦：全年。想在 12 月不刷信用卡的人，用土办法攒圣诞钱：超市圣诞存钱计划（钱锁死在该超市）、52 周挑战（要极强自律）、单开银行账户（靠自觉不挪用）、现金信封。每种凑合都有代价：锁死、靠自律、怕挪用。
这件事到底帮他做什么：一个"不用靠意志力、钱也不会被锁死"的全年圣诞储蓄法——自动、防挪用、12 月能取出来。
谁被现在市面上的产品排除了：自律不够、但又不想被超市 scheme 锁死的人——现有"挑战卡"默认用户有执行力，超市 scheme 默认用户只在该超市花钱。
生活域：钱（全年储蓄习惯）×节庆（圣诞）｜所属语区：英语区
命中的机会镜头：大众常青（全年储蓄是长期需求）＋时间窗口（12 周储蓄挑战现在正是启动季；52 周挑战 1 月启动）
证据：中（跨社区＋视频评论互证；降级点："挑战半途而废"的直接原话多组查询返回空，未找到——判证据不足，≠证伪）
互证出处清单：[1] MSE 2026-01 帖 [2] MSE 2023-11 帖 [3] Mumsnet 2025-11 回帖 [4] mummakingmoney 2025-10 博客 [5] YouTube sinking fund 评论区（佐证亚文化存在）
货架核查：Etsy 圣诞储蓄挑战在售密集——数字 printable $3.08–$4.15（weirdcrittercrew $3.08、SavvyGirlSaves A6 $3.25）；laminated 实物卡 LJHandcraftedCorner $4.15（4.8/33，Star Seller）、SassyPeanutBudgets $4.00；binder 套装 EverythingPrintable1 $2.00（5.0/950）；2027 UK bundle 内含 Christmas 2027 Fund（£500 目标）。结论：在售多为"挑战卡/涂格子"形态；全年 sinking fund 习惯面多为免费内容（博客、MSE 帖），未见"超市 scheme 替代"专项产品。
去重备注：与 S-006 不同面——S-006 是"10 月底才想起来、从现在到圣诞的倒计时储蓄"，本条是"全年 sinking fund/52 周/超市存钱计划的习惯做法"；与 S-002 不同面——S-002 是"储蓄挑战卡空白格要自己算数"的产品麻烦，本条是全年储蓄习惯。
用途标注（2026-10-25，Lee 已定）：供 S-006 全年习惯角度。

## S-037 ｜ 2026-10-24 ｜ 状态：POOL ｜ 来源：远征 2026-10-24（破格入池，主代理裁决）
来源：The Budget Mom YouTube 频道评论区（2024-10—2026-06，持续 8 条独立"求模板/求购买链接"）＋ 已付款买家 @kimkluba6904 评论："I bought the saving trackers and envelopes. Also the binder. How do you make the trackers smaller so it will fit in the binder."（追踪卡和信封、binder 都买了，怎么把追踪卡改小才能塞进 binder？）＋ @WealthIsFreedomBudgets（9 赞）："I tried downsizing to print but it does not come out properly"（试过缩印，印出来不对。）＋ @laurag3619：bundle 里没有封面页
顾客原话：见上（8 条求模板/购买链接＋已付款买家打印尺寸痛点）。
什么时刻、什么麻烦：买了圣诞储蓄追踪卡＋binder 的人，回家打印发现尺寸塞不进 binder（想要 A5），自己缩印印出来是错的；bundle 里还没有封面页。钱花了，东西用不上，要自己折腾打印适配。
这件事到底帮他做什么：买回来就能直接装进 binder 的尺寸（A5 等），附一张封面页，打印设置写清楚不用猜。
谁被现在市面上的产品排除了：用 A5 binder 的人、不会调打印设置的人——现有产品默认"买家自己会搞定打印"。
生活域：钱（圣诞储蓄）×节庆｜所属语区：英语区
命中的机会镜头：产品适配缺口（购买意愿强、卡在交付最后一公里）
证据：中（8 条独立求模板/购买链接跨 20 个月＋1 名已付款买家亲口说打印痛点；属"产品缺口型"信号非典型需求麻烦，破格入池如实标注）
互证出处清单：[1] The Budget Mom 评论区 8 条独立请求（2024-10—2026-06）[2] 已付款买家 @kimkluba6904 打印尺寸痛点 [3] @WealthIsFreedomBudgets（9 赞）缩印失败
货架核查：Etsy 圣诞储蓄/binder 类在售密集（数字 $3.08–$4.15、laminated 实物卡 $4.00–$4.15、binder 套装）；A5 尺寸已有新品在做（如 2027 UK bundle 含 A4/A5/A6），但买家评论中打印适配痛点仍在出现。结论：供给有，但"买回来塞不进 binder"的交付摩擦未被消灭。
裁决备注：本条非典型"麻烦"信号，而是"购买意愿已验证、卡在交付"的产品缺口信号；破格入池，供 Lee 判断是否值得作为现有产品线的补课项。
