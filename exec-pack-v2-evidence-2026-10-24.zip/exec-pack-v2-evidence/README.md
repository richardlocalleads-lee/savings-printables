# EXECUTION-PACK-V2 验证证据包

- live-captures/：2026-10-23 晚场从 Etsy 编辑页逐款抓取的 12 份线上描述全文（原始抓取）。
- EXECUTION-PACK-V2.md：以这 12 份全文为基线重建的披露修复执行包。
- check_pack_v2.py：独立复核脚本。用法：在本目录运行 `python3 check_pack_v2.py`，它从 live-captures 与批准句版独立重算每款 before/after（LEN=UTF-16 码元数，HASH=djb2），并逐字核对执行包内期望值、内嵌脚本的 B/A 数组与追加文本串；全过输出 ALL CHECKS PASS。
