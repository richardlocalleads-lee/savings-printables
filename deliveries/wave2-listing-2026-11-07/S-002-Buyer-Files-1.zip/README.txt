Prefilled Savings Challenge (S-002)
====================================

WHAT'S INSIDE
- 6 prefilled challenges: two each for $100, $500 and $1,000.
  Every square, coin, brick or segment already shows its amount,
  and the amounts add up to the total printed on the page.
- 2 fill-in challenges (squares and coins) with blank amounts,
  so you can set your own numbers and your own total.
- 1 completion log to record each finished challenge.

Files: S-002-Prefilled-Savings-Challenge_A4.pdf and
S-002-Prefilled-Savings-Challenge_Letter.pdf - same 11 pages,
two paper sizes. Print whichever matches your paper.

HOW TO USE
1. Pick a challenge.
2. Each time you set the amount aside, color in one piece.
3. The amounts add up to the total on the page - no math needed.
4. When the picture is full, write it in the Completion Log
   (page 11) and pick your next challenge.

CHOOSING YOUR CHALLENGE
- $100 challenges: small amounts (many $1-$5 pieces). A gentle start.
- $500 challenges: mid-size amounts ($5-$35 pieces).
- $1,000 challenges: bigger amounts ($5-$40 pieces), a longer climb.
You do not have to save on a schedule - one piece at a time,
whenever you can.

THE FILL-IN PAGES (pages 9-10)
Write your own amount in each blank square or coin, add up your
own total on the Total line, then color in a piece each time you
save that amount.

PRINTING
- Print in black and white at 100%, or choose "Fit to page".
- The Contents links (page 2) work on screen in a PDF reader;
  on paper they do nothing.
- Print single pages whenever you like - each challenge stands alone.

LICENSE
Personal use only - see PERSONAL_USE_LICENSE.txt.

Questions about your order? Message us through the shop.
