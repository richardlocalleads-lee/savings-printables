# 备料交付包 — 2026-10-24（待 Lee 核验）

今晚（10-23 晚场）中止上架后备好的全部材料，打包供你亲自核验。本包内容与仓库源文件逐字节一致；关键校验值见清单（S-006 表格全量 SHA-256：18f8d7d3e5f5a170fd0bccdf8690b4065c4056f839d83e36a734e00d75170e3b）。

## 状态说明（核验时请注意）

- D5：全套现成，今晚零改动，只是打包。
- S-006 上架图 M1–M5：原交付只有规格没有图，今晚补建（全部取材于真实文件渲染，M1/M2/M4 带 Example figures 角标）。
- S-006 表格：今晚的现行版（9,645 B）。与旧版差异仅为显示层——合并单元格长文字加自动换行＋行高，公式与数值零改动，修后三种场景已复算全过。旧版（9,613 B）作废，不要用。
- S-006 的 Countdown-Savings-Start-Here.pdf 是现行版，内含占位符 [LINK TO BE INSERTED BY SELLER]——这是设计状态：真实副本链接要在上架场发布门第 4 步才生成回填，现在不要拿它上架。
- EXECUTION-PACK-V2.md：披露修复执行包，以 10-23 晚抓回的 12 份线上全文为基线重建（含 P1 补段落空行、Restart 以线上弯引号版为基线），已通过独立复核脚本逐项校验（基线值、期望 after、内嵌脚本参数逐字比对）。
- LAUNCH-FIELD-2026-10-24.md：上架场执行单（D5 → S-006 发布门 → S-006 上架），下次开场照此走。

## 文件清单

| 文件 | 大小 | SHA-256（前16位） |
|---|---|---|
| D5/LISTING-PACK.md | 11982 B | 1bb1d772ecbe34af… |
| D5/Low-Income-Mini-Challenges-A4.pdf | 58654 B | 4f74f224c2308a85… |
| D5/Low-Income-Mini-Challenges-A6.pdf | 59296 B | e80068a5f05a5ebc… |
| D5/Low-Income-Mini-Challenges-Letter.pdf | 57250 B | e042f1ae197c828d… |
| D5/M1_hero.jpg | 411049 B | 81fc1b2f81da27d4… |
| D5/M2_tier.jpg | 213524 B | 32f6a48ebf04e994… |
| D5/M3_payday.jpg | 183338 B | 23a60b067c0bb539… |
| D5/M4_bend.jpg | 274575 B | 35f7493e7c4cbd72… |
| D5/M5_jars.jpg | 215491 B | a6953b6ad5ae4c56… |
| D5/M6_inside.jpg | 219254 B | 3fd360cbee3d5e46… |
| D5/M7_a6.jpg | 305562 B | 2f03a671b199a1f0… |
| D5/M8_flat.jpg | 232584 B | d60692ecc370ae51… |
| D5/PERSONAL_USE_LICENSE.txt | 900 B | 8ca28abf78e13bd8… |
| D5/Start-Here-Printing-Guide.pdf | 4294 B | 83fe04a07a38fd47… |
| EXECUTION-PACK-V2.md | 29329 B | 9426f5ba5da7301c… |
| LAUNCH-FIELD-2026-10-24.md | 3195 B | 24ebef41bffa1705… |
| S006/Christmas-Countdown-Checkoff-A4.pdf | 29974 B | 4a168a30d488432d… |
| S006/Christmas-Countdown-Checkoff-Letter.pdf | 29823 B | 677ff094c6d59a42… |
| S006/Christmas-Countdown-Savings.xlsx | 9645 B | 18f8d7d3e5f5a170… |
| S006/Countdown-Savings-Start-Here.pdf | 30085 B | 53c17a2abbd2c924… |
| S006/LISTING-PACK.md | 10223 B | 54d3e6a1d8a2bfe2… |
| S006/M1_hero.jpg | 508632 B | 53e5035f4dc7a4c6… |
| S006/M2_respread.jpg | 528355 B | 22b7cf1b4d005ef8… |
| S006/M3_checkoff.jpg | 246934 B | a8419a8444f0c914… |
| S006/M4_inputs.jpg | 260620 B | cfed2dfc11ef36b0… |
| S006/M5_files_sizes.jpg | 318831 B | f06d242e8b4cf7b0… |
| S006/PERSONAL_USE_LICENSE.txt | 918 B | f0c1f1a1219fea0c… |

共 27 个文件。
