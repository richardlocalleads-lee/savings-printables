Veteran End-of-Life Supplement Pages (S-027)
=============================================

Six supplement pages that add the military section to the
end-of-life planner you already have. They are loose pages -
print them and file them with your planner.

WHAT'S INSIDE
- Page 2: VA burial & memorial benefits
- Page 3: Survivor benefits (DIC, Survivors Pension, education,
  CHAMPVA)
- Page 4: Arranging burial & military funeral honors, in order
- Page 5: Military documents checklist (with room to note
  where each document is kept)
- Page 6: Key details & notes

HOW TO USE
1. Print the pages (wide left margin, made for binders/folders).
2. Work through the checklists with your family's details.
3. On page 5, write where each document is kept.
4. File the pages with your end-of-life planner.

PLEASE NOTE
Benefits are set by the VA and change over time. These pages
name the benefits and the forms - they do not promise any
amount or eligibility. Always check the current details at
va.gov before relying on them.

Files: S-027-Veteran-End-of-Life-Supplement_A4.pdf and
S-027-Veteran-End-of-Life-Supplement_Letter.pdf - same 6 pages,
two paper sizes.

PRINTING
- Print in black and white at 100%, or choose "Fit to page".
- Print single pages whenever you like - each page stands alone.

LICENSE
Personal use only - see PERSONAL_USE_LICENSE.txt.

Questions about your order? Message us through the shop.
