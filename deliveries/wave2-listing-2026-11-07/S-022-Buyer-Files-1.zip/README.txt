Expandable End-of-Life Organizer (S-022)
=========================================

A place to write down the information your family would need:
accounts, property, policies, contacts and wishes - organized
your way, because no two lives fit the same number of lines.

WHAT'S INSIDE (base 15 pages + extra prints)
Fixed pages: personal information, where your important
documents are kept, medical & care wishes, funeral wishes,
your will's location and words to leave, notes & reprint guide.
Template pages (pages 5-11): accounts, property, insurance,
contacts, subscriptions, vehicles & valuables, digital accounts.

HOW TO USE
1. Fill in the fixed pages first.
2. Then print the template pages you need:
   - one Accounts page (p.5) for EACH bank or savings account
   - one Property page (p.6) for EACH property
   - one Insurance page (p.7) for EACH policy
   - Contacts (p.8), Subscriptions (p.9), Vehicles (p.10) and
     Digital Accounts (p.11): print as many as you need.
3. Keep it current: when an account closes, take its page out.
   When you open a new one, print another template page.
4. Tell someone you trust where the folder is kept.

PLEASE NOTE
This product is a personal information organizer. It is not a
legal document and does not replace a will, power of attorney,
or legal advice. For anything legal, medical or financial,
please consult a licensed professional.
Never write full passwords or PINs in this book - on the Digital
Accounts page, write only where the password is kept.

Files: S-022-End-of-Life-Expandable-Planner_A4.pdf and
S-022-End-of-Life-Expandable-Planner_Letter.pdf - same base
15 pages, two paper sizes.

PRINTING
- Print in black and white at 100%, or choose "Fit to page".
- The Contents links (page 2) work on screen in a PDF reader;
  on paper they do nothing.
- Template pages are made to be printed again and again.

LICENSE
Personal use only - see PERSONAL_USE_LICENSE.txt.

Questions about your order? Message us through the shop.
