# Fiesta Invitation PNG Pack — File Index (C014-A)

18 transparent PNG graphics + 3 blank border PNGs, for 5x7 invitations.
All files are PNG with a transparent background. The longest edge of each
graphic is about 3000 px; the borders are 2500 x 3500 px (5x7 at 500 dpi).
Combine the graphics with your own text in any photo or design app.

## The 18 graphics

| File | Size (px) | Use |
| ---- | --------- | --- |
| 01-papel-picado-banner.png | 3000 x 805 | Wide banner of five cut-paper flags (pink, orange, yellow, teal, purple). Hang it across the top of the invitation. |
| 02-cactus.png | 1397 x 3000 | Tall saguaro cactus with two arms and a small pink flower. A side or corner accent. |
| 03-sombrero.png | 3000 x 2393 | Festive sombrero with colorful woven bands. A large focal piece, or smaller in a corner. |
| 04-maracas.png | 3000 x 2259 | A pair of maracas crossed in an X. A small accent near the text or at the bottom. |
| 05-chili-pepper.png | 1722 x 3000 | Single red chili pepper with a green stem. A small spicy accent. |
| 06-folk-sun.png | 3000 x 2994 | Smiling folk sun with straight and wavy rays. A cheerful top or center piece. |
| 07-marigold.png | 2313 x 3000 | Orange marigold with green leaves. A floral accent for corners and borders. |
| 08-pinata-donkey.png | 2188 x 3000 | Colorful fringed donkey pinata. The party centerpiece — place it large and low. |
| 09-guitar.png | 1349 x 3000 | Acoustic guitar with colorful stripes. A music accent for the party details. |
| 10-agave.png | 3000 x 2998 | Blue-green agave plant. A tall side accent that frames the text. |
| 11-confetti-burst.png | 2985 x 3000 | A burst of small paper confetti pieces. Scatter it around the text or across a corner. |
| 12-lime-slice.png | 2528 x 3000 | Round lime slice with a leaf. A fresh, small accent. |
| 13-paper-star.png | 3000 x 2908 | Layered yellow and orange paper star. A small bright accent anywhere. |
| 14-cactus-flower.png | 2447 x 3000 | Pink cactus flower bloom with a yellow center. A soft floral accent. |
| 15-ribbon-banner.png | 3000 x 743 | Blank cream ribbon with two small pink flowers. Put your headline, names or date on it — the middle is empty on purpose. |
| 16-monstera-leaf.png | 2450 x 3000 | Deep green monstera leaf with slits and holes. A leafy frame or corner piece. |
| 17-fiesta-arch.png | 3000 x 2270 | Layered scalloped arch with papel picado flags. Frame your text inside the arch. |
| 18-divider-flourish.png | 3000 x 714 | Symmetrical floral divider with leaves and dots. Place it between two blocks of text, or under the headline. |

## The 3 blank borders (5x7)

| File | Size (px) | Use |
| ---- | --------- | --- |
| border-01-papel-picado.png | 2500 x 3500 | Full 5x7 frame: papel picado flags along the top, thin scalloped edge around the rest. Put your whole invitation inside it. |
| border-02-cactus-corners.png | 2500 x 3500 | Full 5x7 frame: small cacti and flowers in the corners with a thin double rule. Put your whole invitation inside it. |
| border-03-floral.png | 2500 x 3500 | Full 5x7 frame: marigolds and leaves at the corners and top and bottom centers, thin rule. Put your whole invitation inside it. |

## Also in this pack

- `LICENSE.txt` — what you may and may not do with these files.
- `preview-5x7-invitation.png` — one example invitation assembled from this pack, so you can see how the pieces work together. Your invitation will use your own text.

No SVG or EPS files are included. Nothing in this pack promises the
graphics can be cut with a cutting machine.
