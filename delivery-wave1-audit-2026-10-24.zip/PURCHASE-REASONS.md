# 购买理由挖掘 — 前线 B（双周薪预算）＋前线 A（圣诞储蓄）

> 用途：直接喂 pin 文案与演示脚本。只收录买家亲口说的付款理由与劝退点，卖家文案一律不算证据。
> 采集日：2026-10-24。方法与口径见文末「证据口径与抓取失败清单」——先说清：Etsy listing 页文本抓取不渲染评价区正文，本轮评价原文来自 Etsy 官方市场页 Review spotlight 中**带完整 listing 标题署名**的评价逐条收割，每款收割到的条数如实标注，未达「每款通读 15–25 条」的样本已在表中标明样本量，不用聚合摘要凑数。店铺累计销量/店铺评分一律与单品数据分开标注。

---

# 前线 B：双周薪预算类（对照本店 D3）

## 头部样本表

| # | Listing（店） | 价格 | 评价（listing 级） | 链接 |
|---|---|---|---|---|
| B1 | Biweekly Paycheck Budget Spreadsheet Excel Google Sheets Fortnightly Budget Planner…（TheSheetCode） | $8.97（原价 $22.43，常驻 60% off） | **4.9 分 / 95 条**；页面带「过去 6 个月高销量」徽标（单品级信号） | https://www.etsy.com/listing/1797861917/biweekly-paycheck-budget-spreadsheet |
| B2 | Biweekly Bimonthly Budget Planner Google Sheets Spreadsheet…｜Green（JrenDigital） | $6.80（50% off） | listing 级评价数未抓到（店铺级 4.8 分/5,553 条，不计入单品） | https://www.etsy.com/listing/1612090749/biweekly-bimonthly-budget-planner-google |
| B3 | Biweekly Paycheck Budget Spreadsheet Bill Calendar Weekly Monthly Budget Planner…（店名未抓到） | 约 $10.9–13.2（原价约 $21.8） | 未抓到（已收割署名评价 2 条） | 未抓到 |
| B4 | Biweekly Paycheck Budget Planner｜Printable PDF & Excel Spreadsheet｜Pink Ledger（TheStructuredLedger） | $8.99（未见折扣标示） | 未抓到（页面可开，评价原文未收割到） | https://www.etsy.com/listing/4594956211/biweekly-paycheck-budget-planner |
| B5 | Biweekly Budget Planner, EDITABLE Bi-weekly Template, PDF Printable Paycheck Budget Tracker…（店名未抓到） | $1.88（原价 $3.13） | 未抓到（已收割署名评价 2 条） | 未抓到 |

## 购买理由分类表

| 理由 | 支持条数 | 代表原话（原文＋翻译） | 出处 |
|---|---|---|---|
| **跟发薪节奏对齐**：按 pay period 记账，不用月度模板硬套双周薪 | 2 | "This budget tracker is perfect for tracking my spending biweekly, just like my pay periods. Because I get paid bi-weekly I use this to track my income and expenses and make sure I account for every cent."（这个追踪器正合我的双周发薪节奏，我用它记每一笔收入支出，确保每一分钱都有去处。）／"I love that you can track each pay period"（我喜欢它能逐个发薪周期地记。） | B1（Michael Fox 5★；Sarah King 5★） |
| **每一块钱都有去处**：全面覆盖、一处装下全部财务信息 | 2 | "make sure I account for every cent"（确保每一分钱都记到账。）／"The spreadsheet is easy to use and it has a place for all my financial information."（这张表好用，我所有的财务信息在里面都有位置。） | B1（Michael Fox 5★）；B3（Annette White 5★） |
| **说明清楚、易上手**：说明页/直觉设计把「怕复杂」拆掉 | 2 | "So easy to set up. The instructions are easy to follow!"（设置很简单，说明一看就懂！）／"The template is intuitive, beautifully designed"（模板很直觉、设计得漂亮。） | B1（Cyna M 5★；Alexis 5★） |
| **客服响应快、肯教**（服务型理由，非产品功能） | 2 | "the customer service was quick and responsive when I had questions"（我有问题时客服回复又快又到位。）／"the customer service is phenomenal… They will help you in choosing what is best for you."（客服好得没话说……他们会帮你选最适合你的用法。） | B1（Michael Fox 5★；Cyna M 5★） |
| **目标分开记**：应急金有独立 tracker，不和度假/圣诞目标混在一起 | 1（弱） | "my favorite factor that sets it apart from the others is that it has its own designated emergency fund tracker… I love that I don't have to lump my emergency savings in with all the other savings goals like vacation and Christmas."（它真正拉开差距的一点是有专门的应急金追踪表……我不用再把应急储蓄和度假、圣诞这些目标混成一团。） | B1（Sarah King 5★） |
| **混合发薪频率家庭也能用**：一方月薪、一方双周薪 | 1（弱） | "I struggled with choosing biweekly & monthly because my husband is paid 1x per month & Im biweekly."（我之前纠结选双周还是月度版，因为我先生月薪、我是双周薪。） | B1（Cyna M 5★） |

类目旁证（不计入上表计数）：另一 listing 的买家 Julieanne 5★："Great tool, easy to use both the pdf and the YouTube video were helpful"（工具很好用，PDF 和 YouTube 视频教程都很有帮助。）——「视频教程」在类目里是真实的易上手证据。

## 劝退点清单（前线 B）

1. **太多、太复杂、被压垮**（类目第一劝退点，3 处出处）：
   - "Great listing but it's a little much budgeting for me. I really needed a basic paycheck to paycheck calculator."（东西是好，但对我来说预算做得太重了，我其实只需要一个基本的按支票算钱的工具。）— B3，JeDon Mabrie 4★
   - "Very thorough, to the point where it could be overwhelming."（全面到有点让人吃不消。）— JrenDigital 店铺评价 4★（评价未标注具体 listing，按店铺级证据计）
   - "Very detailed budgeting system, could be a bit overwhelming"（非常细的预算系统，可能有点让人吃不消。）— JrenDigital 店铺评价 5★（同上）
2. **美国中心、非美国用户要大量调校**："Its based/focused primarily on users living in the USA so needs a lot of fine tuning to get it "suited" to you if you don't live in the USA."（它主要按美国用户设计，不住美国的话要花很多功夫调到适合自己。）— JrenDigital 店铺评价 4★（Michael）
3. **性价比被同类比下去**："Needed a biweekly budget. This would work, but there are better ones out there with more things that are cheaper."（我需要双周预算。这个能用，但外面有功能更多、还更便宜的。）— B5，Danelle 4★
4. **下载/访问摩擦**（卖家 FAQ 自证，非买家原话，单列标注）：TheSheetCode FAQ 明示手机 App 内无法下载数字文件，须用电脑；JrenDigital FAQ 第一条即「打开是 View Only 怎么办→File > Make a copy」，且明示 Etsy App 内无法下载、须改用手机浏览器——「买完打不开/找不到入口」是这类目要靠 FAQ 常年灭火的固定摩擦。

## 对照本店 D3 三态标注

D3 事实基线（出处：`biweekly-paycheck-planner/LISTING-PACK.md` 定版包＋ Excel 全量实测记录 2026-10-21）：14 页打印模板（英＋繁中、A4＋Letter）＋ Excel 5 表（Start Here／26 Paychecks／Paycheck Worksheet／Bills Split／Year at a Glance）；核心页 Bill Split Planner 把月账单按到期日分给 Paycheck 1/2；年度页 SUMIF 全公式自动汇总（26 期实测 12/12 对数）；第三薪月有 Bonus Paycheck Plan 页；售价 $9.99。

| 竞品被证实的理由/劝退点 | D3 状态 | 依据 |
|---|---|---|
| 跟发薪节奏对齐 | **真具备** | 全品即围绕 Payday Map＋Bill Split＋26 期发薪记录设计，定版包描述第一段就是这个主张 |
| 每一块钱都有去处（全面覆盖） | **真具备** | 账单、支出（按 P1/P2 打标）、债务、储蓄基金、储蓄目标全覆盖，14 页清单在定版包内 |
| 说明清楚、易上手（说明页部分） | **具备但页面没说清** | 有 Quick Start 页（5 步）＋ Excel Start Here 表，但定版包 4 张 listing 图与描述前段都没有把「5 步开始」推到买家眼前 |
| 视频教程 | **不具备** | 定版包无任何视频资产；竞品（B1 及类目旁证）靠 YouTube 教程拿到「易上手」评价 |
| 客服承诺 | **真具备** | 定版包描述末行明示「File problem? Message me — I'll fix or replace the file within 24 hours.」 |
| 应急金独立 tracker | **不具备** | 有 Sinking Funds＋Savings Goal 通用机制可承接，但没有单列命名的应急金追踪（B1 买家点名这是「拉开差距」的一点） |
| 混合发薪频率家庭 | **不具备** | 排期与表格按双周薪 26 期设计并实测，月薪配偶无对应机制 |
| 劝退点「太复杂」 | **真具备防线但页面没说清** | D3 是「一页核心（Bill Split）＋其余按需」的结构，复杂度低于 B1 的多 tab 大包，但页面没有明说「只需先用一页」 |
| 劝退点「下载摩擦」 | **真具备防线** | D3 是 Etsy 直接下载的 PDF＋xlsx（无云端链接、无 Make a copy 环节），天然避开 B2 类的 View Only 摩擦；定版包未把这点写成卖点 |

## 可直接用的 pin / 视频角度（前线 B）

1. **发薪对齐**（踩理由 1，2 条评价支持）— 图面主标：`YOUR BILLS ARE MONTHLY. YOUR PAYCHECK ISN'T.` 视频拍法：把月账单逐张拖进 Paycheck 1 / Paycheck 2 两列，第三薪月那张单独亮出来。
2. **每块钱有去处**（踩理由 2，2 条评价支持）— 主标：`EVERY BILL GETS A PAYCHECK.` 图面用 Bill Split 页特写（D3 现有 listing_split.png 即此页）。
3. **先用一页就行**（正打类目第一劝退点「太复杂」；D3 防线真具备但页面没说清）— 主标：`START WITH ONE PAGE. THE REST IS THERE WHEN YOU NEED IT.`
4. **第三薪月**（D3 独有页 Bonus Paycheck Plan，竞品评价无人提及此点，是空位）— 主标：`THIRD-PAYCHECK MONTH? IT ALREADY HAS A JOB.` 视频拍法：Payday Map 上两个三薪月标记＋Bonus 页 10 秒带过。
5. **不用跟云端链接搏斗**（踩劝退点 4；D3 直接下载属实）— 主标：`NO LINKS. NO 'MAKE A COPY'. JUST FILES YOU OWN.`（仅在 pin 落地文案里用，不进 listing 标题，避免影射竞品。）

---

# 前线 A：圣诞储蓄类（对照本店 S-006＋Christmas Kit）

## 头部样本表

| # | Listing（店） | 价格 | 评价（listing 级） | 链接 |
|---|---|---|---|---|
| A1 | Christmas Gift Tracker, Christmas Planner…Spreadsheet Template, Holiday Gift Google Sheets（SavvyandThriving） | $3.67（原价 $7.35） | **4.8 分 / 119 条** | https://www.etsy.com/listing/1421940361/christmas-gift-tracker-christmas-planner |
| A2 | Christmas Planner & Budget Spreadsheet Google Sheets Excel Template Digital Gift Tracker…（店名未抓到） | 未抓到 | 未抓到（已收割署名评价 2 条） | 未抓到 |
| A3 | Christmas Gift Tracker Google Sheets: Gift Planner Spreadsheet…Card Tracker + FREE BONUS!（店名未抓到） | 未抓到 | 未抓到（已收割署名评价 2 条） | 未抓到 |
| A4 | Christmas Savings Challenge Printable Bundle, Mini A6…系列（EraPrintable，多变体） | $2.52–$3.89（各变体售价） | 未抓到（已收割署名评价 2 条） | https://www.etsy.com/listing/1800582442/christmas-savings-challenge-printable（Santa 变体） |
| A5 | Ultimate Christmas Tracker Spreadsheet Google Sheets, Gift Tracker, Card Tracker…（店名未抓到） | 未抓到 | 未抓到（已收割署名评价 1 条，长文含功能许愿） | 未抓到 |

## 购买理由分类表

| 理由 | 支持条数 | 代表原话（原文＋翻译） | 出处 |
|---|---|---|---|
| **全部集中在一处**：礼物、预算、卡片、记录不再散落 | 2 | "this has all I need combined in one location with totals calculating automatically"（我需要的全在这一个地方，总额还自动算好；此前她只用手机备忘录记。）／"I love the graphs and checklists and details… the base is solid"（我喜欢它的图表、清单和细节……底子很扎实。） | A5（Cayla McDonough 5★）；A2（grey 5★） |
| **比自己做更好**：省下自制表格的时间和功夫 | 2 | "This tracker was SO worth the small cost. I was planning to set one up myself but came to Etsy to see what they had first and this one is better than I could have done myself!"（这表太值这点钱了。我本来打算自己做一个，先来 Etsy 看看，结果这个比我自己能做的好！）／grey 原为多年自制表格用户："this one is by far my favorite"（这个是我用过最喜欢的一个。） | A3（Stephanie Judice 5★）；A2（grey 5★） |
| **控住预算、不再临时抱佛脚** | 2 | "It was helpful to keep track of presents and stay on budget during Christmas time."（它帮我记清礼物、整个圣诞季没超预算。）／"I normally find the holiday season very stressful due to a lack of budgeting… Yay for no more last minute shopping!"（往年我因为没做预算整个节日季都很焦虑……终于不用再临时抱佛脚买东西了！） | A3（Bethzaely Feliciano 5★）；Holiday Budget Spreadsheet & Christmas Gift Tracker（Kaelie Dotter 5★） |
| **可爱、好玩，愿意开始**（打印挑战线的成交理由） | 3 | "Cutest christmas printables ever! Thank you!"（最可爱的圣诞打印品，没有之一！）／"Love these christmas challenges. Going to be fun saving for christmas."（太喜欢这些圣诞挑战了，为圣诞存钱会变得好玩。）／"Cute and budget friendly Christmas savings challenge."（可爱又省钱的圣诞储蓄挑战。） | A4（Brenda Contour 5★；Cynthia 5★）；500 Christmas Savings Challenge Printable（Cynthia Salmon 5★） |
| **年年复用、跨节日复用** | 2 | "Helped me plan my budget for this christmas and future christmas'"（帮我规划了今年和以后每年圣诞的预算。）／"I will be using it for future holidays like mother's day and father's day."（母亲节、父亲节我还要拿它来用。） | A2（Eric 5★）；A3（Bethzaely 5
...[truncated 10056 chars]
---

## 补强记录（2026-10-24 午间，实况浏览器补摘后由主审追加；原始存档 REVIEW-HARVEST-2026-10-24.md）

初版每款仅 1–4 条署名评价，系文本抓取路径的上限，并非信息源的上限——实况浏览器登出状态即可渲染评价区，本轮补摘：TheSheetCode 16 条、JrenDigital 19 条、SavvyandThriving 18 条（均含低星筛选）。据此修订结论可信度：

**被加强（证据从「弱/旁证」升为多条 listing 级原文）**
1. **视频/可视化安装说明是表格类的硬购买理由**：JrenDigital 两条 5★直接点名 YouTube 教程（"Love the youtube tutorial! It made it very easy to navigate."）；TheSheetCode 一条长评点名 "in-depth visual/video for set up… step by step instructions"。连同初版旁证，合计 4 条独立原文。→ 第二波「D3/S-006 演示视频」的优先级上调为前线 B/A 的共同动作，不再只是 B 类建议。
2. **客服响应**在 TheSheetCode 16 条里出现 4 次（immaculate/fantastic/above and beyond 等），确认为该店的复购级理由；本店靠描述末行 24 小时修文件承诺＋真人回复承接，口径不变。
3. **劝退点「太复杂」再添实证**：JrenDigital 2★ "Too complicated and confusing to use"、"It was hard to use"——与初版 3 处合并，类目第一劝退点地位不变，D3「先用一页」防线继续成立。
4. **下载摩擦从 FAQ 推断升为买家实证**：JrenDigital 2★ "I could not get this to open or download to my computer."——D3 直接下载、S-006 三件套拆雷的价值有真实差评背书。

**新增可用角度（前线 B）**
5. **「名为双周、实为月度」是真实差评点**：JrenDigital 2★ "advertised as biweekly but caters to a monthly schedule"。D3 是双周原生设计（26 期实测），可正面打：「Built for biweekly from the first cell — not a monthly sheet in disguise.」进 pin 角度库，listing 文案不用（避免影射）。

**被降级**
6. 前线 A「可爱、好玩」：EraPrintable 该 listing 本身只有 1 条评价（1★，打印问题），初版 3 条「可爱」原文属同店同系列其他 listing——降级为**系列级证据**，方向仍成立（打印挑战靠好玩成交），但不得再表述为该商品的买家证据。另：SavvyandThriving 1★ "could not actually track the gifts and total" 提示圣诞表格的底线是「礼物与总计必须真能记」——Christmas Kit 的每人 cap＋实际花费总览正是答这条，角度不变、证据更实。
